/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file memory.h
 * @brief ORIC-1 Memory management (64KB addressable)
 * @author bmarty <bmarty@mailo.com>
 * @date 2026-01-31
 * @version 0.1.0-alpha
 *
 * ORIC-1 Memory Map:
 * $0000-$00FF: Zero Page
 * $0100-$01FF: Stack
 * $0200-$02FF: System variables
 * $0300-$030F: VIA 6522 (mirrored in $0300-$03FF)
 * $0400-$BFFF: User RAM / Screen RAM ($BB80-$BFDF)
 * $C000-$F7FF: BASIC ROM (or RAM overlay)
 * $F800-$FFFF: Monitor ROM (always ROM for vectors)
 */

#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>
#include <stdbool.h>

#define MEMORY_SIZE 65536  /**< Total addressable memory (64KB) */
#define RAM_SIZE    49152  /**< User RAM size (48KB) */
#define ROM_SIZE    16384  /**< ROM size (16KB) */


/**
 * @brief Memory access types (for debugging/tracing)
 */
typedef enum {
    MEM_READ,
    MEM_WRITE,
    MEM_EXEC
} mem_access_type_t;

/**
 * @brief Memory banking mode
 */
typedef enum {
    BANK_ROM,   /**< ROM mapped */
    BANK_RAM    /**< RAM overlay mapped */
} memory_bank_t;

/**
 * @brief Memory subsystem structure
 */
typedef struct memory_s {
    uint8_t ram[RAM_SIZE];      /**< Main RAM */
    uint8_t rom[ROM_SIZE];      /**< ROM (BASIC + Monitor) */
    uint8_t charset[2048];      /**< Character set ROM */
    uint8_t upper_ram[ROM_SIZE]; /**< RAM behind ROM area ($C000-$FFFF) for Microdisc overlay */

    memory_bank_t charset_bank; /**< Character set banking */
    bool rom_enabled;           /**< ROM enable flag */

    /* Microdisc overlay ROM support */
    uint8_t* overlay_rom;         /**< Overlay ROM data (microdis.rom) */
    uint32_t overlay_rom_size;    /**< Overlay ROM size in bytes */
    bool overlay_active;          /**< Overlay ROM mapped at $E000-$FFFF */
    bool basic_rom_disabled;      /**< BASIC ROM disabled (romdis) */

    /* Jasmin disk interface banking ($F800-$FFFF boot ROM). Distinct from the
     * Microdisc overlay: olay=RAM everywhere, romdis pages the 2 KB Jasmin ROM
     * at $F800 with RAM at $C000-$F7FF (Oricutron jasmin_atmosread). */
    bool jasmin_active;           /**< Jasmin present → use Jasmin banking */
    const uint8_t* jasmin_rom;    /**< 2 KB Jasmin boot ROM ($F800-$FFFF) */
    bool jasmin_olay;             /**< $03FA overlay RAM: RAM everywhere */
    bool jasmin_romdis;           /**< $03FB: Jasmin ROM in, BASIC ROM out */

    /* I/O device callbacks */
    uint8_t (*io_read)(uint16_t address, void* userdata);
    void (*io_write)(uint16_t address, uint8_t value, void* userdata);
    /* Side-effect-free I/O read for observers (memory_peek). NULL → memory_peek
     * falls back to io_read. See memory_peek() and io_device_t::peek. */
    uint8_t (*io_peek)(uint16_t address, void* userdata);
    void* io_userdata;

    /* Memory access tracing (for debugging) */
    bool trace_enabled;
    void (*trace_callback)(uint16_t address, uint8_t value, mem_access_type_t type);
    /* Secondary independent trace hook (conditional CPU trace, Epic 6/US1).
     * Fires whenever non-NULL, regardless of trace_enabled, so it can coexist
     * with the watchpoint callback above. */
    void (*trace_callback2)(uint16_t address, uint8_t value, mem_access_type_t type);

    /* RAM stuck-bit fault injection (Epic 6/US6, parity with b2 "RAM errors").
     * Applied to main-RAM ($0000-$BFFF) reads: value = (v & ~stuck0) | stuck1.
     * Both zero = no faults (zero cost). */
    uint8_t stuck0;   /* bits forced to 0 */
    uint8_t stuck1;   /* bits forced to 1 */

    /* Open-bus latch: last byte actually driven on the data bus during a
     * read (instruction fetch, operand, memory read). On a real 6502 an
     * undriven access (no peripheral puts the data on the bus in time)
     * latches this bus residue, not a fixed value. Used to model the lost
     * PHI2 race of the LOCI at $0380 (VIA inhibited → floating bus). See io_bus.c. */
    uint8_t last_bus_value;

} memory_t;

/**
 * @brief Initialize memory subsystem
 *
 * @param mem Pointer to memory structure
 * @return true on success, false on failure
 */
bool memory_init(memory_t* mem);

/**
 * @brief Cleanup memory subsystem
 *
 * @param mem Pointer to memory structure
 */
void memory_cleanup(memory_t* mem);

/**
 * @brief Load ROM file
 *
 * @param mem Pointer to memory structure
 * @param filename Path to ROM file
 * @param offset Offset in ROM to load at
 * @return true on success, false on failure
 */
bool memory_load_rom(memory_t* mem, const char* filename, uint16_t offset);

/**
 * @brief Load character set ROM
 *
 * @param mem Pointer to memory structure
 * @param filename Path to charset file
 * @return true on success, false on failure
 */
bool memory_load_charset(memory_t* mem, const char* filename);

/**
 * @brief Read byte from memory
 *
 * @param mem Pointer to memory structure
 * @param address Address to read from
 * @return Byte value
 */
uint8_t memory_read(memory_t* mem, uint16_t address);

/**
 * @brief Peek a byte WITHOUT side effects (observers: debugger, monitor, dump)
 *
 * Identical to memory_read() for RAM/ROM, but for the I/O window ($0300-$03FF)
 * it routes to the side-effect-free io_peek callback instead of io_read. This
 * prevents an observer that samples memory from perturbing hardware — notably
 * from silently consuming ACIA RX bytes (reading DATA clears RDRF). It also
 * does NOT fire memory trace/watchpoint hooks. If no io_peek is registered it
 * falls back to io_read (historical behavior).
 *
 * @param mem Pointer to memory structure
 * @param address Address to read from
 * @return Byte value (no state change)
 */
uint8_t memory_peek(memory_t* mem, uint16_t address);

/**
 * @brief Write byte to memory
 *
 * @param mem Pointer to memory structure
 * @param address Address to write to
 * @param value Byte value to write
 */
void memory_write(memory_t* mem, uint16_t address, uint8_t value);

/**
 * @brief Read 16-bit word (little-endian)
 *
 * @param mem Pointer to memory structure
 * @param address Address to read from
 * @return Word value
 */
uint16_t memory_read_word(memory_t* mem, uint16_t address);

/**
 * @brief Write 16-bit word (little-endian)
 *
 * @param mem Pointer to memory structure
 * @param address Address to write to
 * @param value Word value to write
 */
void memory_write_word(memory_t* mem, uint16_t address, uint16_t value);

/**
 * @brief Set I/O callbacks for memory-mapped I/O
 *
 * @param mem Pointer to memory structure
 * @param read_cb Read callback function
 * @param write_cb Write callback function
 * @param userdata User data passed to callbacks
 */
void memory_set_io_callbacks(memory_t* mem,
                             uint8_t (*read_cb)(uint16_t, void*),
                             void (*write_cb)(uint16_t, uint8_t, void*),
                             void* userdata);

/**
 * @brief Register the side-effect-free I/O read callback used by memory_peek()
 *
 * @param mem Pointer to memory structure
 * @param peek_cb Peek callback (routes to io_device_t::peek, non-destructive)
 */
void memory_set_io_peek(memory_t* mem,
                        uint8_t (*peek_cb)(uint16_t, void*));

/**
 * @brief Enable/disable memory access tracing
 *
 * @param mem Pointer to memory structure
 * @param enabled true to enable, false to disable
 * @param callback Trace callback function
 */
void memory_set_trace(memory_t* mem, bool enabled,
                     void (*callback)(uint16_t, uint8_t, mem_access_type_t));

/** @brief Set the secondary trace hook (NULL to disable). Independent of
 *  memory_set_trace, so watchpoints and the conditional CPU trace coexist. */
void memory_set_trace2(memory_t* mem,
                     void (*callback)(uint16_t, uint8_t, mem_access_type_t));

/** @brief Set RAM stuck-bit masks (Epic 6/US6). stuck0 = bits forced to 0,
 *  stuck1 = bits forced to 1, applied to $0000-$BFFF reads. 0,0 = disabled. */
void memory_set_stuck_bits(memory_t* mem, uint8_t stuck0, uint8_t stuck1);

/** @brief Last byte driven on the data bus (open-bus). Returns the value
 *  an unserved access would latch on a real 6502. Used to model the lost
 *  PHI2 race of the LOCI ($0380, VIA inhibited). */
uint8_t memory_open_bus(const memory_t* mem);

/**
 * @brief Clear all RAM
 *
 * @param mem Pointer to memory structure
 * @param pattern Fill pattern (0x00 or 0xFF typical)
 */
void memory_clear_ram(memory_t* mem, uint8_t pattern);

/**
 * @brief Get pointer to memory region (direct access for speed)
 * WARNING: Use with caution, bypasses banking and I/O
 *
 * @param mem Pointer to memory structure
 * @param address Starting address
 * @return Pointer to memory region or NULL if invalid
 */
uint8_t* memory_get_ptr(memory_t* mem, uint16_t address);

#endif /* MEMORY_H */
