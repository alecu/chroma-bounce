/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file cli_options.h
 * @brief CLI option declarations (enum of long codes + getopt table).
 * @author bmarty <bmarty@mailo.com>
 *
 * Extracted from main.c (Epic 7 / partial US3, Sprint 127). SEPARATES the option
 * *declarations* (data) from the *parsing logic* (the getopt switch, in
 * src/cli/cli_args.c since sprint C).
 *
 * Sprint C (2.3.0): the option variables live in cli_opts_t (cli/cli_opts.h),
 * the switch is in cli_parse_args(), verbatim. Deliberately NOT done: the
 * *declarative* parser (a generic table replacing the switch) -- no measurable
 * benefit while the `case`s remain plain assignments, and any behaviour change
 * would have to be justified against tools/cli_golden.sh.
 *
 * Included by src/cli/cli_args.c only (defines long_options[] as static).
 */
#ifndef CLI_OPTIONS_H
#define CLI_OPTIONS_H

#include <getopt.h>

/* Codes of the long options without a short equivalent (>= 256 so as not to
 * collide with the short option characters). */
enum {
    OPT_SCREENSHOT = 256, OPT_SCREENSHOT_AT, OPT_FRAME_DUMP, OPT_FRAME_DUMP_INTERVAL,
    OPT_TYPE_KEYS, OPT_DISK_ROM, OPT_DISK1, OPT_DISK2, OPT_DISK3, OPT_BREAKPOINT,
    OPT_DEBUG_BREAK, OPT_CAST_SERVER, OPT_CAST_DISCOVER, OPT_CAST_TO, OPT_SAVE_STATE,
    OPT_LOAD_STATE, OPT_MODEL, OPT_JOYSTICK, OPT_PRINTER, OPT_PRINTER_TYPE, OPT_SCALE,
    OPT_TRACE, OPT_TRACE_MAX, OPT_TRACE_RING, OPT_CYCLE_TRACE, OPT_CYCLE_TRACE_MAX, OPT_CPU_MICROSEQ, OPT_CPU_LEGACY, OPT_ULA_CYCLE, OPT_ULA_LINE, OPT_ULA_FETCH_OFFSET, OPT_PROFILE, OPT_ROM_INFO,
    OPT_DISK_WRITEBACK, OPT_DUMP_RAM_AT, OPT_TRACE_IRQ, OPT_SYMBOLS,
    OPT_TUI, OPT_LOCI, OPT_LOCI_FLASH, OPT_LOCI_SDIMG, OPT_LOCI_MIA_WINDOW,
    OPT_LOCI_SERVE_TIMING, OPT_LOCI_SERVE_JITTER, OPT_LOCI_EMU, OPT_LOCI_EMU_USB_IMAGE, OPT_LOCI_EMU_CDC, OPT_LOCI_EMU_FLASH, OPT_LOCI_HW, OPT_LOCI_MENU_AT,
    OPT_CONTROL, OPT_BENCH, OPT_RENDER_SOFTWARE, OPT_VIDEO, OPT_VIDEO_FPS,
    OPT_VIDEO_QUALITY, OPT_GDB, OPT_RECORD, OPT_REPLAY, OPT_NO_BORDER,
    OPT_EXPORT_BORDER, OPT_REALTIME, OPT_DISK_CREATE, OPT_BAD_SECTOR, OPT_FDC_TIMING, OPT_DISK_WRITE_PROTECT,
    OPT_LOCI_USB, OPT_TAPE_SIGNAL, OPT_TAPE_SIGNAL_FREE, OPT_HTTP_API, OPT_HTTP_API_BIND, OPT_HTTP_API_ROOT,
    OPT_PSG_TRACE, OPT_KBD_TRACE, OPT_AUDIO_WAV, OPT_SCREENSHOT_TEXT,
    OPT_SCREENSHOT_ANSI, OPT_SCREENSHOT_TEXT_AT, OPT_SCREENSHOT_ANSI_AT,
    OPT_SCREENSHOT_WHEN, OPT_DUMP_RAM_WHEN, OPT_SCREENSHOT_TEXT_WHEN,
    OPT_TYPE_KEYS_WHEN, OPT_POKE_AT, OPT_POKE_WHEN, OPT_TAPE_OUT_CAPTURE,
    OPT_DISK_WEB, OPT_LOCI_WEB, OPT_LOCI_WEB_BASE, OPT_JASMIN_ROM,
    OPT_CONFIG, OPT_NO_CONFIG, OPT_MENU_SCREENSHOT, OPT_GDB_BIND, OPT_NO_CONFIG_CARDS, OPT_NO_ROM,
    OPT_NO_AUTO_LOCI
};

/* Short option string passed to getopt_long. */
#define CLI_SHORT_OPTIONS "t:d:r:h:fnc:vm:k:j:p:b:D?"

/* getopt table of the long options (terminated by {0,0,0,0}). */
static const struct option long_options[] = {
    {"tape",                required_argument, 0, 't'},
    {"disk",                required_argument, 0, 'd'},
    {"disk1",               required_argument, 0, OPT_DISK1},
    {"disk2",               required_argument, 0, OPT_DISK2},
    {"disk3",               required_argument, 0, OPT_DISK3},
    {"disk-writeback",      no_argument,       0, OPT_DISK_WRITEBACK},
    {"disk-create",         required_argument, 0, OPT_DISK_CREATE},
    {"disk-web",            required_argument, 0, OPT_DISK_WEB},
    {"rom",                 required_argument, 0, 'r'},
    {"hostfs",              required_argument, 0, 'h'},
    {"fast-load",           no_argument,       0, 'f'},
    {"headless",            no_argument,       0, 'n'},
    {"realtime",            no_argument,       0, OPT_REALTIME},
    {"tape-signal",         no_argument,       0, OPT_TAPE_SIGNAL},
    {"tape-signal-free",    no_argument,       0, OPT_TAPE_SIGNAL_FREE},
    {"tape-out-capture",    required_argument, 0, OPT_TAPE_OUT_CAPTURE},
    {"cycles",              required_argument, 0, 'c'},
    {"verbose",             no_argument,       0, 'v'},
    {"screenshot",          required_argument, 0, OPT_SCREENSHOT},
    {"screenshot-at",       required_argument, 0, OPT_SCREENSHOT_AT},
    {"screenshot-text",     required_argument, 0, OPT_SCREENSHOT_TEXT},
    {"screenshot-ansi",     required_argument, 0, OPT_SCREENSHOT_ANSI},
    {"screenshot-text-at",  required_argument, 0, OPT_SCREENSHOT_TEXT_AT},
    {"screenshot-ansi-at",  required_argument, 0, OPT_SCREENSHOT_ANSI_AT},
    {"screenshot-when",     required_argument, 0, OPT_SCREENSHOT_WHEN},
    {"screenshot-text-when",required_argument, 0, OPT_SCREENSHOT_TEXT_WHEN},
    {"frame-dump",          required_argument, 0, OPT_FRAME_DUMP},
    {"frame-dump-interval", required_argument, 0, OPT_FRAME_DUMP_INTERVAL},
    {"video",               required_argument, 0, OPT_VIDEO},
    {"video-fps",           required_argument, 0, OPT_VIDEO_FPS},
    {"video-quality",       required_argument, 0, OPT_VIDEO_QUALITY},
    {"gdb",                 optional_argument, 0, OPT_GDB},
    {"gdb-bind",            required_argument, 0, OPT_GDB_BIND},
    {"no-config-cards",     no_argument,       0, OPT_NO_CONFIG_CARDS},
    {"no-auto-loci",        no_argument,       0, OPT_NO_AUTO_LOCI},
    {"no-rom",              no_argument,       0, OPT_NO_ROM},
    {"record",              required_argument, 0, OPT_RECORD},
    {"replay",              required_argument, 0, OPT_REPLAY},
    {"keyboard",            required_argument, 0, 'k'},
    {"type-keys",           required_argument, 0, OPT_TYPE_KEYS},
    {"type-keys-when",      required_argument, 0, OPT_TYPE_KEYS_WHEN},
    {"disk-rom",            required_argument, 0, OPT_DISK_ROM},
    {"jasmin-rom",          required_argument, 0, OPT_JASMIN_ROM},
    {"breakpoint",          required_argument, 0, 'b'},
    {"debug",               no_argument,       0, 'D'},
    {"break",               required_argument, 0, OPT_DEBUG_BREAK},
    {"cast-server",         optional_argument, 0, OPT_CAST_SERVER},
    {"http-api",            optional_argument, 0, OPT_HTTP_API},
    {"http-api-bind",       required_argument, 0, OPT_HTTP_API_BIND},
    {"http-api-root",       required_argument, 0, OPT_HTTP_API_ROOT},
    {"cast-to",             optional_argument, 0, OPT_CAST_TO},
    {"cast-discover",       no_argument,       0, OPT_CAST_DISCOVER},
    {"save-state",          required_argument, 0, OPT_SAVE_STATE},
    {"load-state",          required_argument, 0, OPT_LOAD_STATE},
    {"model",               required_argument, 0, 'm'},
    {"joystick",            required_argument, 0, 'j'},
    {"printer",             required_argument, 0, 'p'},
    {"printer-type",        required_argument, 0, OPT_PRINTER_TYPE},
    {"scale",               required_argument, 0, OPT_SCALE},
    {"render-software",     no_argument,       0, OPT_RENDER_SOFTWARE},
    {"no-border",           no_argument,       0, OPT_NO_BORDER},
    {"export-border",       no_argument,       0, OPT_EXPORT_BORDER},
    {"trace",               required_argument, 0, OPT_TRACE},
    {"trace-max",           required_argument, 0, OPT_TRACE_MAX},
    {"cpu-microseq",        no_argument,       0, OPT_CPU_MICROSEQ},
    {"cpu-legacy",          no_argument,       0, OPT_CPU_LEGACY},
    {"ula-cycle",           no_argument,       0, OPT_ULA_CYCLE},
    {"ula-line",            no_argument,       0, OPT_ULA_LINE},
    {"ula-fetch-offset",    required_argument, 0, OPT_ULA_FETCH_OFFSET},
    {"cycle-trace",         required_argument, 0, OPT_CYCLE_TRACE},
    {"cycle-trace-max",     required_argument, 0, OPT_CYCLE_TRACE_MAX},
    {"trace-ring",          required_argument, 0, OPT_TRACE_RING},
    {"profile",             required_argument, 0, OPT_PROFILE},
    {"rom-info",            optional_argument, 0, OPT_ROM_INFO},
    {"dump-ram-at",         required_argument, 0, OPT_DUMP_RAM_AT},
    {"dump-ram-when",       required_argument, 0, OPT_DUMP_RAM_WHEN},
    {"poke-at",             required_argument, 0, OPT_POKE_AT},
    {"poke-when",           required_argument, 0, OPT_POKE_WHEN},
    {"bad-sector",          required_argument, 0, OPT_BAD_SECTOR},
    {"fdc-timing",          required_argument, 0, OPT_FDC_TIMING},
    {"disk-write-protect",  no_argument,       0, OPT_DISK_WRITE_PROTECT},
    {"trace-irq",           required_argument, 0, OPT_TRACE_IRQ},
    {"psg-trace",           required_argument, 0, OPT_PSG_TRACE},
    {"kbd-scan-trace",      required_argument, 0, OPT_KBD_TRACE},
    {"config",              required_argument, 0, OPT_CONFIG},
    {"no-config",           no_argument,       0, OPT_NO_CONFIG},
    {"menu-screenshot",     required_argument, 0, OPT_MENU_SCREENSHOT},
    {"audio-wav",           required_argument, 0, OPT_AUDIO_WAV},
    {"symbols",             required_argument, 0, OPT_SYMBOLS},
    {"tui",                 no_argument,       0, OPT_TUI},
    {"loci",                no_argument,       0, OPT_LOCI},
    {"loci-flash",          required_argument, 0, OPT_LOCI_FLASH},
    {"loci-emu",            required_argument, 0, OPT_LOCI_EMU},
    {"loci-usb-image",      required_argument, 0, OPT_LOCI_EMU_USB_IMAGE},
    {"loci-cdc",            required_argument, 0, OPT_LOCI_EMU_CDC},
    {"loci-emu-flash",      required_argument, 0, OPT_LOCI_EMU_FLASH},
    {"loci-hw",             required_argument, 0, OPT_LOCI_HW},
    {"loci-sdimg",          required_argument, 0, OPT_LOCI_SDIMG},
    {"loci-usb",            required_argument, 0, OPT_LOCI_USB},
    {"loci-web",            required_argument, 0, OPT_LOCI_WEB},
    {"loci-web-base",       required_argument, 0, OPT_LOCI_WEB_BASE},
    {"loci-mia-window",     required_argument, 0, OPT_LOCI_MIA_WINDOW},
    {"loci-serve-timing",   required_argument, 0, OPT_LOCI_SERVE_TIMING},
    {"loci-serve-jitter",   required_argument, 0, OPT_LOCI_SERVE_JITTER},
    {"loci-menu-at",        required_argument, 0, OPT_LOCI_MENU_AT},
    {"control",             no_argument,       0, OPT_CONTROL},
    {"bench",               no_argument,       0, OPT_BENCH},
    {"help",                no_argument,       0, '?'},
    {0, 0, 0, 0}
};

#endif /* CLI_OPTIONS_H */
