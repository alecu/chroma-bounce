/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file loci_emu_stub.c
 * @brief Replacement for loci_emu.c when the RP2040 emulator (libemul) is absent
 * @author bmarty <bmarty@mailo.com>
 * @date 2026-09-11
 *
 * The `--loci-emu` backend runs the real LOCI firmware inside an external
 * RP2040 emulator (`~/loci/emul`, not versioned in this repository). Without
 * it, the Makefile links only this file: the emulator builds and works
 * fully -- including `--loci`, which is the behavioural backend and does not
 * depend on the firmware -- and `--loci-emu` fails cleanly at startup.
 * `make LOCI_EMU=1 LOCI_EMUL_DIR=...` restores the co-simulation.
 *
 * In a native binary, this is the « no external LOCI » backend of the
 * dispatch (loci_backend.c, functions renamed by loci_be_rename.h). The
 * web build links it alone, without dispatch: it then also provides
 * loci_emu_select and loci_emu_backend_available.
 */
#include "io/loci_emu.h"
#include "utils/logging.h"

int loci_emu_start(const char *elf_path)
{
    log_error("--loci-emu: co-simulation RP2040 non compilée dans ce binaire "
              "(libemul absente au build) ; firmware ignoré : %s", elf_path ? elf_path : "");
    return -1;
}

void loci_emu_set_usb_image(const char *path) { (void)path; }
void loci_emu_set_flash_image(const char *path) { (void)path; }
void loci_emu_stop(void) { }
bool loci_emu_active(void) { return false; }
const char *loci_emu_backend_name(void) { return "stub"; }
int loci_emu_reset_take(void) { return 0; }
int loci_emu_idle_poll(int cycles) { (void)cycles; return 0; }
bool loci_emu_menu_button(void) { return false; }
bool loci_emu_button_was_warm(void) { return false; }
bool loci_emu_wait_boot(void) { return false; }
bool loci_emu_diag_button(void) { return false; }

bool loci_emu_rom_read(uint16_t address, uint8_t *out)
{
    (void)address; (void)out;
    return false;
}

void loci_emu_ext_lines(int *nirq, int *nreset, int *nromdis)
{
    if (nirq) *nirq = 1;
    if (nreset) *nreset = 1;
    if (nromdis) *nromdis = 1;
}

void    loci_emu_api_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_api_read(uint16_t address) { (void)address; return 0xFF; }
int     loci_emu_irq_take(void) { return 0; }

void    loci_emu_set_cdc_device(const char *path) { (void)path; }
void    loci_emu_dsk_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_dsk_read(uint16_t address) { (void)address; return 0xFF; }
bool    loci_emu_romdis(void) { return false; }
bool    loci_emu_acia_served(uint16_t address) { (void)address; return false; }
void    loci_emu_dsk_tick(void) { }
void    loci_emu_tap_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_tap_read(uint16_t address) { (void)address; return 0xFF; }
void    loci_emu_tap_motor(uint8_t via_orb) { (void)via_orb; }
bool    loci_emu_acia_active(void) { return false; }
void    loci_emu_acia_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_acia_read(uint16_t address) { (void)address; return 0xFF; }
uint8_t loci_emu_acia_peek(uint16_t address) { (void)address; return 0xFF; }
void    loci_emu_acia_tick(void) { }

void loci_emu_tick(long steps) { (void)steps; }

bool loci_emu_mou_report(uint8_t buttons, int8_t dx, int8_t dy, int8_t wheel, int8_t pan)
{
    (void)buttons; (void)dx; (void)dy; (void)wheel; (void)pan;
    return false;
}
bool loci_emu_mou_armed(void) { return false; }

bool loci_emu_kbd_report(uint8_t modifier, const uint8_t keycodes[6])
{
    (void)modifier; (void)keycodes;
    return false;
}
bool loci_emu_kbd_armed(void) { return false; }

bool loci_emu_rom_write(uint16_t address, uint8_t value) { (void)address; (void)value; return false; }

/* Whole I/O page via bus cycles: specific to the neo backend (loci-fw). */
bool    loci_emu_io_page(void) { return false; }
bool    loci_emu_io_read(uint16_t address, uint8_t *out) { (void)address; (void)out; return false; }
void    loci_emu_io_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
bool    loci_emu_read_lost(void) { return false; }

#ifndef LOCI_BE   /* linked alone (web build): no dispatch */
bool loci_emu_select(const char *backend) { (void)backend; return false; }
bool loci_emu_backend_available(const char *backend) { (void)backend; return false; }
#endif
