/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file loci_neo.c
 * @brief Co-sim backend for the NEW LOCI firmware "loci-fw" (rewritten from scratch)
 * @author bmarty <bmarty@mailo.com>
 * @date 2026-09-17
 *
 * Same interface as loci_emu.c (backend of the upstream firmware) but no symbol from
 * that firmware: everything goes through the `emul_neo` bridge of ~/loci/emul (emulation
 * contract ADR-003: `loci_rom_image`/`loci_rom_base`, I²C expander, PIO bus cycles).
 *   - reads $C000-$FFFF: served in O(1) when /ROMDIS is active;
 *   - writes $C000-$FFFF (BAL page $FF, ADR-002): real bus cycles to the PIO;
 *   - page $03xx: not decoded by loci-fw for now → floating bus ($FF).
 * Selection: `make LOCI_NEO=1`, then `--loci-emu <loci-fw.elf>`.
 */
#include "io/loci_emu.h"
#include "utils/logging.h"
#include "emul_neo.h"
#include "bus.h"
#include "soc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>

static emul_t g_emul;
static int    g_active;
static int    g_reset_pending;   /* Oric /RESET asserted by the firmware, to be delivered to the 6502 */
static char   g_usb_image[1024]; /* --loci-usb-image: emulated USB stick (FAT image) */
static int    g_hid;             /* emulated USB keyboard/mouse (usbhid_* hooks) */
static char   g_cdc_dev[1024];   /* --loci-cdc: emulated serial dongle (PTY) */

/* Watches the /RESET line while the firmware runs (14/5: third-party ROM). */
static void neo_run(long steps)
{
    emul_step(&g_emul, steps);
    int nreset = 0; emul_ext_lines(&g_emul, NULL, &nreset, NULL);
    if (nreset) g_reset_pending = 1;
}

/* Preloading of files into the internal FS (test): LOCI_NEO_FILES="NAME=path,NAME=path".
 * Writes each file through the BAL (group 3, channel 7, 190-byte chunks via $FF10). */
static void neo_preload_files(void)
{
    const char *spec = getenv("LOCI_NEO_FILES");
    if (!spec || !*spec) return;
    char buf[4096]; strncpy(buf, spec, sizeof buf - 1); buf[sizeof buf - 1] = 0;
    for (char *tok = strtok(buf, ","); tok; tok = strtok(NULL, ",")) {
        char *eq = strchr(tok, '=');
        if (!eq) continue;
        *eq = 0;
        const char *name = tok, *path = eq + 1;
        FILE *f = fopen(path, "rb");
        if (!f) { log_warning("LOCI-neo: préchargement « %s » : %s illisible", name, path); continue; }
        size_t nl = strlen(name); if (nl > 79) nl = 79;
        neo_bus_write(&g_emul, 0xFF10, (uint8_t)nl);
        for (size_t i = 0; i < nl; i++) neo_bus_write(&g_emul, (uint16_t)(0xFF11 + i), (uint8_t)name[i]);
        uint8_t po[4] = { 7, 0x10, 0xFF, 3 };
        if (!neo_bal_call(&g_emul, 3, 4, po, 4)) { fclose(f); continue; }
        uint8_t chunk[190]; size_t n, total = 0;
        while ((n = fread(chunk, 1, sizeof chunk, f)) > 0) {
            for (size_t i = 0; i < n; i++) neo_bus_write(&g_emul, (uint16_t)(0xFF10 + i), chunk[i]);
            uint8_t pw[5] = { 7, 0x10, 0xFF, (uint8_t)n, (uint8_t)(n >> 8) };
            if (!neo_bal_call(&g_emul, 3, 9, pw, 5)) break;
            total += n;
        }
        fclose(f);
        uint8_t pc[1] = { 7 }; neo_bal_call(&g_emul, 3, 5, pc, 1);
        log_info("LOCI-neo: préchargé « %s » (%zu octets) depuis %s", name, total, path);
    }
}

int loci_emu_start(const char *elf_path)
{
    if (emul_init(&g_emul, elf_path, 0x10000100u) != 0) {
        log_error("LOCI-neo: emul_init a échoué (%s)", elf_path);
        return -1;
    }
    if (g_cdc_dev[0]) {
        int fd = open(g_cdc_dev, O_RDWR | O_NOCTTY | O_NONBLOCK);
        if (fd >= 0) { struct termios t; if (tcgetattr(fd, &t) == 0) { t.c_lflag &= ~(tcflag_t)(ICANON | ECHO | ISIG | IEXTEN); t.c_iflag &= ~(tcflag_t)(ICRNL | INLCR | IXON | ISTRIP); t.c_oflag &= ~(tcflag_t)OPOST; tcsetattr(fd, TCSANOW, &t); } }   /* raw: a PTY is canonical by default */
        if (fd >= 0 && neo_serial_attach_fd(&g_emul, fd)) log_info("LOCI-neo: dongle série émulé sur « %s » (groupe 10)", g_cdc_dev);
        else log_warning("LOCI-neo: dongle série « %s » indisponible", g_cdc_dev);
    }
    g_hid = neo_hid_enable(&g_emul);
    if (!g_hid) log_warning("LOCI-neo: symboles usbhid_* absents — clavier/souris USB non émulés");
    if (g_usb_image[0]) {
        if (neo_usb_set_image(&g_emul, g_usb_image)) log_info("LOCI-neo: clé USB émulée « %s » (volume 1:)", g_usb_image);
        else log_warning("LOCI-neo: image USB « %s » illisible ou symboles usbdisk_* absents", g_usb_image);
    }
    log_info("LOCI-neo: firmware loci-fw (%s) — boot…", elf_path);
    if (!neo_boot(&g_emul)) {
        log_error("LOCI-neo: le firmware n'a pas armé le service ROM (/ROMDIS, nOE, /RESET)");
        return -1;
    }
    g_active = 1;
    uint8_t lo = 0, hi = 0;
    neo_serve_read(&g_emul, 0xFFFC, &lo); neo_serve_read(&g_emul, 0xFFFD, &hi);
    log_info("LOCI-neo: ROM servie, vecteur reset = $%02X%02X", hi, lo);
    neo_preload_files();
    return 0;
}

void loci_emu_set_usb_image(const char *path) { if (path) { strncpy(g_usb_image, path, sizeof g_usb_image - 1); g_usb_image[sizeof g_usb_image - 1] = 0; } }
void loci_emu_set_flash_image(const char *path) { (void)path; }
void loci_emu_set_cdc_device(const char *path) { if (path) { strncpy(g_cdc_dev, path, sizeof g_cdc_dev - 1); g_cdc_dev[sizeof g_cdc_dev - 1] = 0; } }
void loci_emu_stop(void) { if (g_active) { emul_free(&g_emul); g_active = 0; } }
bool loci_emu_active(void) { return g_active != 0; }
const char *loci_emu_backend_name(void) { return "neo"; }
int  loci_emu_reset_take(void)
{
    if (!g_reset_pending) return 0;
    /* wait for the firmware to release /RESET */
    for (int k = 0; k < 200; k++) {
        int nreset = 0; emul_ext_lines(&g_emul, NULL, &nreset, NULL);
        if (!nreset) break;
        emul_step(&g_emul, 1000L);
    }
    g_reset_pending = 0;
    log_info("LOCI-neo: /RESET Oric relâché par le firmware → redémarrage du 6502");
    return 1;
}
int  loci_emu_idle_poll(int cycles) { (void)cycles; return 0; }
bool loci_emu_wait_boot(void) { return g_active != 0; }
/* Cartridge button (Ctrl+Alt+M): short press → the firmware brings the Oric back to the
 * kernel (/RESET). The firmware polls the button every 20 ms: we advance emulated time. */
bool loci_emu_menu_button(void)
{
    if (!g_active) return false;
    emul_ioexp_set(&g_emul, EXT_REG_IN, 0x00);            /* pressed (active low) */
    int seen = 0, nreset = 0;
    for (int k = 0; k < 4000; k++) {
        soc_timer_advance_us(5000);
        emul_step(&g_emul, 1000L);
        emul_ext_lines(&g_emul, NULL, &nreset, NULL);
        if (nreset) seen = 1;
        if (seen && !nreset) break;
    }
    emul_ioexp_set(&g_emul, EXT_REG_IN, 0x04);            /* released */
    emul_step(&g_emul, 100000L);
    g_reset_pending = 0;                                   /* delivered here: the caller does cpu_reset */
    if (seen) log_info("LOCI-neo: bouton → retour au kernel (/RESET)");
    return seen != 0;
}
bool loci_emu_button_was_warm(void) { return false; }
bool loci_emu_diag_button(void) { return false; }

bool loci_emu_rom_read(uint16_t address, uint8_t *out)
{
    if (!g_active) return false;
    int served = neo_serve_read(&g_emul, address, out);
    /* Polling of $FF00 during a command (WaitMessage): the model is event-driven,
     * the firmware does not run between two accesses → advance it on each read, otherwise a
     * long command (littlefs commit) never completes (same principle as the poll in
     * loci_emu.c). */
    if (served && address == 0xFF00u && out && *out != 0 && !g_reset_pending) {
        neo_run(2000L);
        neo_serve_read(&g_emul, address, out);
    }
    return served != 0;
}

bool loci_emu_rom_write(uint16_t address, uint8_t value)
{
    if (!g_active || address < 0xC000u) return false;
    /* Only page $FF is captured by LOCI (BAL): real bus cycle. Elsewhere, the board
     * ignores the write. */
    if ((address & 0xFF00u) == 0xFF00u) neo_bus_write(&g_emul, address, value);
    /* Group write = start of command: advance the firmware until completion
     * ($FF00 = 0) or a ceiling — the model is event-driven, the firmware does not run
     * between two 6502 accesses (same principle as the poll in loci_emu.c). */
    if (address == 0xFF00u && value) {
        for (int k = 0; k < 500; k++) {
            uint8_t g = 0xFF;
            neo_peek(&g_emul, 0xFF00, &g);
            if (g == 0 || g_reset_pending) break;
            neo_run(1000L);
        }
    }
    /* Address served by LOCI: the write stops here (the ROM masks the RAM). /MAP window
     * (batch 8.2): not served → false, memory.c writes the Oric overlay RAM. */
    return neo_serve_read(&g_emul, address, NULL) != 0;
}

bool loci_emu_romdis(void)
{
    if (!g_active) return false;
    int nromdis = 0;
    emul_ext_lines(&g_emul, NULL, NULL, &nromdis);
    return nromdis != 0;
}

void loci_emu_ext_lines(int *nirq, int *nreset, int *nromdis)
{
    if (!g_active) { if (nirq) *nirq = 0; if (nreset) *nreset = 0; if (nromdis) *nromdis = 0; return; }
    emul_ext_lines(&g_emul, nirq, nreset, nromdis);
}

/* Page $03xx: nothing decoded by loci-fw in batch 1. */
void    loci_emu_api_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_api_read(uint16_t address) { (void)address; return 0xFF; }
/* I/O page $0310-$03FF (batch 8.0): real bus cycles; the firmware then advances a little
 * (its core 1 handles the captured access, core 0 prepares what follows). */
bool loci_emu_io_page(void) { return g_active != 0; }
bool loci_emu_read_lost(void) { return false; }
bool loci_emu_io_read(uint16_t address, uint8_t *out)
{
    if (!g_active) return false;
    int drv = neo_io_read(&g_emul, address, out);
    neo_run(200L);
    return drv != 0;
}
void loci_emu_io_write(uint16_t address, uint8_t value)
{
    if (!g_active) return;
    neo_bus_write(&g_emul, address, value);
    neo_run(200L);
}
void    loci_emu_dsk_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_dsk_read(uint16_t address) { (void)address; return 0xFF; }
void    loci_emu_tap_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_tap_read(uint16_t address) { (void)address; return 0xFF; }
/* Cassette motor (VIA ORB PB6): LOCI snoops writes to $0300 on the real bus;
 * replayed here only when PB6 changes (the ROM rewrites ORB at each keyboard column). */
void loci_emu_tap_motor(uint8_t via_orb)
{
    static int last = -1;
    int motor = (via_orb >> 6) & 1;
    if (!g_active || motor == last) return;
    last = motor;
    neo_bus_write(&g_emul, 0x0300, via_orb);
}
/* Once per frame: the firmware also advances when the 6502 does not access LOCI (it may
 * wait for the WD1793 end-of-command IRQ without reading anything — batch 8.2). Φ2 idles
 * high: the service SMs wait for the next edge, nothing gets desynchronized. */
void    loci_emu_dsk_tick(void)
{
    if (!g_active) return;
    /* Called once per frame (20 ms of Oric time): the firmware time follows the Oric's
     * (otherwise it only advances by 1 µs per timer read — the sound engine, clocked at 50 Hz,
     * made no progress; batch 9.1). */
    soc_timer_advance_us(20000);
    neo_run(20000L);
}
/* Firmware /IRQ pulses (expander, bit 5), counted by soc.c on the rising edge. */
int     loci_emu_irq_take(void) { return g_active ? emul_loci_irq_take(&g_emul) : 0; }
bool    loci_emu_acia_active(void) { return false; }
bool    loci_emu_acia_served(uint16_t address) { (void)address; return false; }
void    loci_emu_acia_write(uint16_t address, uint8_t value) { (void)address; (void)value; }
uint8_t loci_emu_acia_read(uint16_t address) { (void)address; return 0xFF; }
uint8_t loci_emu_acia_peek(uint16_t address) { (void)address; return 0xFF; }
void    loci_emu_acia_tick(void) { }

/* Background task: the firmware runs freely (main loop) once per frame. */
void loci_emu_tick(long steps) { if (g_active) neo_run(steps); }

/* Emulated USB HID (host keyboard/mouse → firmware usbhid_* contract). */
bool loci_emu_mou_report(uint8_t buttons, int8_t dx, int8_t dy, int8_t wheel, int8_t pan)
{ (void)pan; if (!g_hid) return false; neo_hid_mouse_report(buttons, dx, dy, wheel, 1); return true; }
bool loci_emu_mou_armed(void) { return g_hid != 0; }
bool loci_emu_kbd_report(uint8_t modifier, const uint8_t keycodes[6])
{ if (!g_hid) return false; neo_hid_key_report(modifier, keycodes); return true; }
bool loci_emu_kbd_armed(void) { return g_hid != 0; }
