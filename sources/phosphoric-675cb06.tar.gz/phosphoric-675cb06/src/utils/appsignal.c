/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file appsignal.c
 * @brief Shutdown-signal handling — implementation.
 * @author bmarty <bmarty@mailo.com>
 *
 * Extracted from main.c (Epic 7 / US1, Sprint 125), unchanged.
 */
#include "utils/appsignal.h"

#include <signal.h>

static volatile bool g_running = true;

static void signal_handler(int sig) {
    (void)sig;
    g_running = false;
}

void app_install_signal_handlers(void) {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
}

bool app_should_run(void) {
    return g_running;
}
