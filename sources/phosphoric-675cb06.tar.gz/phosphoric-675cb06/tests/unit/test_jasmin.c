/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file test_jasmin.c
 * @brief Jasmin disk interface tests (WD177x FDC + .dsk write-back wiring)
 * @author bmarty <bmarty@mailo.com>
 *
 * Covers the fix reported by the bbsoric team: a guest sector write on a
 * Jasmin machine must (1) mark the Jasmin's own dirty flag and (2) be picked
 * up by the write-back path, which previously consulted only the Microdisc.
 * The write-back sites (osd_writeback_drive/control_writeback_drive/quit flush)
 * are static functions, but they now all delegate to the emu_disk_* helpers in
 * emulator.h — so testing those helpers + sedoric_save round-trip proves the
 * whole chain persists a Jasmin guest save byte-exact.
 */

#define _DEFAULT_SOURCE   /* mkstemp under -std=c11 -pedantic */
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>

#include "emulator.h"
#include "io/jasmin.h"
#include "storage/sedoric.h"
#include "storage/disk.h"

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) static void name(void)
#define RUN(name) do { \
    printf("  %-50s", #name); \
    name(); \
    tests_passed++; \
    printf("PASS\n"); \
} while(0)

#define ASSERT_EQ(a, b) do { \
    if ((a) != (b)) { \
        printf("FAIL\n    %s:%d: expected 0x%X, got 0x%X\n", __FILE__, __LINE__, (unsigned)(b), (unsigned)(a)); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_TRUE(x) do { \
    if (!(x)) { \
        printf("FAIL\n    %s:%d: expected true\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_FALSE(x) do { \
    if ((x)) { \
        printf("FAIL\n    %s:%d: expected false\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

/* ── Helper-level: the active interface's dirty flag is consulted ──────────
 * emu_disk_dirty/emu_disk_clear_dirty/emu_disk_max_drives must follow
 * has_jasmin, not hard-code the Microdisc. This is the exact predicate the
 * three write-back sites now gate on. */
TEST(test_emu_disk_helpers_follow_active_iface) {
    emulator_t* emu = calloc(1, sizeof(*emu));
    ASSERT_TRUE(emu != NULL);

    /* Jasmin machine: only jasmin.disk_dirty must count. */
    emu->card_on[CARD_IDX_jasmin] = true;
    emu->card_on[CARD_IDX_microdisc] = false;
    ASSERT_EQ(emu_disk_max_drives(emu), JASMIN_MAX_DRIVES);

    emu->microdisc.disk_dirty[2] = true;   /* stale Microdisc flag — must be ignored */
    ASSERT_FALSE(emu_disk_dirty(emu, 2));

    emu->jasmin.disk_dirty[2] = true;
    ASSERT_TRUE(emu_disk_dirty(emu, 2));
    ASSERT_FALSE(emu_disk_dirty(emu, 0));

    emu_disk_clear_dirty(emu, 2);
    ASSERT_FALSE(emu_disk_dirty(emu, 2));
    ASSERT_TRUE(emu->jasmin.disk_dirty[2] == false);

    /* Out-of-range guard. */
    ASSERT_FALSE(emu_disk_dirty(emu, -1));
    ASSERT_FALSE(emu_disk_dirty(emu, JASMIN_MAX_DRIVES));

    /* Microdisc machine: the Microdisc flag counts, Jasmin's is ignored. */
    emu->card_on[CARD_IDX_jasmin] = false;
    emu->card_on[CARD_IDX_microdisc] = true;
    ASSERT_EQ(emu_disk_max_drives(emu), MICRODISC_MAX_DRIVES);
    emu->jasmin.disk_dirty[1] = true;      /* leftover — must be ignored now */
    ASSERT_FALSE(emu_disk_dirty(emu, 1));
    emu->microdisc.disk_dirty[1] = true;
    ASSERT_TRUE(emu_disk_dirty(emu, 1));
    emu_disk_clear_dirty(emu, 1);
    ASSERT_FALSE(emu_disk_dirty(emu, 1));

    free(emu);
}

/* ── End-to-end: a guest sector write through the Jasmin FDC marks the Jasmin
 * dirty, mutates the shared emu->disks[]->data buffer, and survives a
 * sedoric_save/sedoric_load round-trip (the persistence the bbsoric sink needs).
 * The write is driven through jasmin_write() exactly as the CPU would, mirroring
 * test_fdc_write_sector but via the Jasmin register window. */
TEST(test_jasmin_guest_write_persists) {
    char path[] = "/tmp/phos_jasmin_wb_XXXXXX";
    int fd = mkstemp(path);
    ASSERT_TRUE(fd >= 0);
    close(fd);

    sedoric_disk_t* disk = sedoric_create();     /* standard Sedoric geometry */
    ASSERT_TRUE(disk != NULL);

    jasmin_t j;
    memset(&j, 0, sizeof(j));
    jasmin_init(&j);
    j.fdc.timing_mode = FDC_TIMING_FAST;         /* deterministic DRQ cadence */
    jasmin_set_disk(&j, 0, disk->data, disk->size, disk->tracks, disk->sectors);

    /* Position on track 0, sector 1 and issue a Write Sector ($A0). */
    j.fdc.c_track = 0;
    j.fdc.track = 0;
    j.fdc.sector = 1;
    jasmin_write(&j, JASMIN_FDC_BASE, 0xA0);
    ASSERT_EQ(j.fdc.currentop, FDC_OP_WRITE_SECTOR);

    fdc_ticktock(&j.fdc, 505);                   /* wait for first DRQ */
    ASSERT_EQ(j.drq, 0x00);                       /* DRQ active on the Jasmin line */

    for (int i = 0; i < 256; i++) {
        jasmin_write(&j, JASMIN_FDC_BASE + 3, (uint8_t)i);
        if (i < 255) fdc_ticktock(&j.fdc, 35);
    }
    ASSERT_EQ(j.fdc.currentop, FDC_OP_NONE);

    /* (1) Jasmin dirty flag set by jasmin_write's disk_modified consumption. */
    ASSERT_TRUE(j.disk_dirty[0]);
    /* (2) The write landed in the SAME buffer sedoric_save will flush. */
    ASSERT_EQ(disk->data[0], 0x00);
    ASSERT_EQ(disk->data[1], 0x01);
    ASSERT_EQ(disk->data[255], 0xFF);

    /* (3) Persist and reload: the guest save must be on the .dsk file. */
    ASSERT_TRUE(sedoric_save(disk, path));
    sedoric_disk_t* reloaded = sedoric_load(path);
    ASSERT_TRUE(reloaded != NULL);
    ASSERT_EQ(reloaded->data[1], 0x01);
    ASSERT_EQ(reloaded->data[255], 0xFF);

    sedoric_destroy(reloaded);
    sedoric_destroy(disk);
    unlink(path);
}

/* ── Hot-swap routing: emu_disk_wire() installs/ejects on the ACTIVE controller.
 * The OSD (F6/Suppr) and control (load-disk/eject-disk) hot-swap paths now route
 * through this helper, so on a Jasmin machine the media must land in the Jasmin
 * controller (not the Microdisc), and an eject (nd==NULL) must clear it. */
TEST(test_emu_disk_wire_routes_to_active_iface) {
    emulator_t* emu = calloc(1, sizeof(*emu));
    ASSERT_TRUE(emu != NULL);
    emu->card_on[CARD_IDX_jasmin] = true;
    emu->card_on[CARD_IDX_microdisc] = false;
    jasmin_init(&emu->jasmin);

    sedoric_disk_t* disk = sedoric_create();
    ASSERT_TRUE(disk != NULL);

    /* Install into drive B: the Jasmin drive-B slot must point at the buffer,
     * and the Microdisc must stay untouched. */
    emu_disk_wire(emu, 1, disk);
    ASSERT_TRUE(emu->jasmin.disk_data[1] == disk->data);
    ASSERT_EQ(emu->jasmin.disk_size[1], disk->size);
    ASSERT_TRUE(emu->microdisc.disk_data[1] == NULL);

    /* Eject: the Jasmin slot must be cleared. */
    emu_disk_wire(emu, 1, NULL);
    ASSERT_TRUE(emu->jasmin.disk_data[1] == NULL);
    ASSERT_EQ(emu->jasmin.disk_size[1], 0u);

    sedoric_destroy(disk);
    free(emu);
}

/* ── Bad-sector injection (--bad-sector on a Jasmin machine). The damage lives
 * with the media (per-drive map) and is synced into the live FDC map when the
 * target is the selected drive. Mirrors the Microdisc. */
TEST(test_jasmin_bad_sector_injection) {
    jasmin_t j;
    memset(&j, 0, sizeof(j));
    jasmin_init(&j);                 /* selects drive 0 */

    /* Inject on the selected drive: recorded in the media map AND synced live. */
    ASSERT_EQ(jasmin_add_bad_sector(&j, 0, 0, 10, 3), 0);
    ASSERT_EQ(j.bad_map[0].count, 1);
    ASSERT_EQ(j.bad_map[0].entry[0].track, 10);
    ASSERT_EQ(j.bad_map[0].entry[0].sector, 3);
    ASSERT_EQ(j.fdc.bad.count, 1);   /* live FDC map re-pointed (selected drive) */

    /* Inject on a non-selected drive: recorded on its media, live map untouched. */
    ASSERT_EQ(jasmin_add_bad_sector(&j, 2, 0, 5, 7), 0);
    ASSERT_EQ(j.bad_map[2].count, 1);
    ASSERT_EQ(j.fdc.bad.count, 1);   /* still drive 0's map under the head */

    /* Out-of-range drive is rejected. */
    ASSERT_EQ(jasmin_add_bad_sector(&j, JASMIN_MAX_DRIVES, 0, 1, 1), -1);
}

/* ── Double-sided Jasmin (side-2). The WD1770/1772 has no SIDE pin; the Jasmin
 * drives it externally via $03F8. A guest write with side 1 selected must land
 * in the side-1 region of the flat image — offset side*(tracks*spt) — and leave
 * side 0 untouched. This proves the $03F8 side-select feeds fdc->side, which the
 * offset formula (disk.c) consumes. */
TEST(test_jasmin_side_select_double_sided) {
    const uint8_t TPS = 2;                       /* tracks per side (small) */
    sedoric_disk_t* disk = sedoric_create_blank(TPS, 2);  /* 2 sides */
    ASSERT_TRUE(disk != NULL);
    ASSERT_EQ(disk->sides, 2);
    ASSERT_EQ(disk->data[0], 'S');               /* side-0/t0/s1 signature */

    jasmin_t j;
    memset(&j, 0, sizeof(j));
    jasmin_init(&j);
    j.fdc.timing_mode = FDC_TIMING_FAST;
    jasmin_set_disk(&j, 0, disk->data, disk->size, disk->tracks, disk->sectors);

    /* Select side 1 via $03F8 (external side-select). */
    jasmin_write(&j, JASMIN_SIDE, 1);
    ASSERT_EQ(j.side, 1);
    ASSERT_EQ(j.fdc.side, 1);

    /* Write track 0 / sector 1 on side 1. */
    j.fdc.c_track = 0;
    j.fdc.track = 0;
    j.fdc.sector = 1;
    jasmin_write(&j, JASMIN_FDC_BASE, 0xA0);
    ASSERT_EQ(j.fdc.currentop, FDC_OP_WRITE_SECTOR);
    fdc_ticktock(&j.fdc, 505);
    ASSERT_EQ(j.drq, 0x00);
    for (int i = 0; i < 256; i++) {
        jasmin_write(&j, JASMIN_FDC_BASE + 3, (uint8_t)i);
        if (i < 255) fdc_ticktock(&j.fdc, 35);
    }
    ASSERT_EQ(j.fdc.currentop, FDC_OP_NONE);

    /* side1/t0/s1 lands at offset side*(tracks*spt) = 1*(2*17)=34 sectors. */
    uint32_t off = (uint32_t)1 * TPS * disk->sectors * 256;
    ASSERT_EQ(disk->data[off + 1], 0x01);
    ASSERT_EQ(disk->data[off + 255], 0xFF);
    /* Side 0 must be untouched: its signature is still intact. */
    ASSERT_EQ(disk->data[0], 'S');
    ASSERT_EQ(disk->data[1], 'E');
    ASSERT_EQ(disk->data[2], 'D');

    sedoric_destroy(disk);
}

/* ── Section .ost « JAS » (sprint D). ─────────────────────────────────────── */
static long jas_bytes(FILE* fp, unsigned char* buf, long cap) {
    long n = ftell(fp);
    if (n > cap) return -1;
    rewind(fp);
    if (fread(buf, 1, (size_t)n, fp) != (size_t)n) return -1;
    return n;
}

/* Every saved field is restored: FDC registers and latches filled with a
 * pattern, non-empty bad-sector maps; fresh copy reloaded then saved
 * again → same bytes. */
TEST(test_jasmin_save_load_restores_every_field) {
    static uint8_t img[4][16 * 17 * 256];
    jasmin_t a, b;
    memset(&a, 0, sizeof(a)); memset(&b, 0, sizeof(b));
    jasmin_init(&a); jasmin_init(&b);
    for (int d = 0; d < JASMIN_MAX_DRIVES; d++) {
        jasmin_set_disk(&a, (uint8_t)d, img[d], sizeof(img[d]), 16, 17);
        jasmin_set_disk(&b, (uint8_t)d, img[d], sizeof(img[d]), 16, 17);
    }
    /* Distinctive source state (values clamped where loading clamps). */
    /* Every field written by fdc_state_save gets a distinct value. */
    a.fdc.status = 0x91; a.fdc.command = 0x8C; a.fdc.track = 33; a.fdc.sector = 7;
    a.fdc.data = 0xA5; a.fdc.direction = 1; a.fdc.c_track = 34; a.fdc.c_sector = 8;
    a.fdc.side = 1; a.fdc.currentop = (fdc_op_t)2;
    a.fdc.cur_sector_len = 256; a.fdc.cur_offset = 77; a.fdc.sec_type = 0x20;
    a.fdc.delayed_drq = 31; a.fdc.delayed_int = 1203; a.fdc.di_status = 0x44;
    a.fdc.dd_status = 0x03; a.fdc.status_type1 = true; a.fdc.rot_pos = 12345;
    a.fdc.drq_age = 29; a.fdc.wt_state = 1; a.fdc.wt_field_idx = 2;
    a.fdc.wt_id[0] = 5; a.fdc.wt_id[1] = 1; a.fdc.wt_id[2] = 9; a.fdc.wt_id[3] = 1;
    a.fdc.wt_data_len = 256; a.fdc.wt_sectors_done = 4;
    a.romdis = true; a.olay = true; a.drive = 2; a.side = 1; a.fdc.side = 1;
    a.intrq = 0x00; a.drq = 0x00; a.autoboot_done = true;
    ASSERT_EQ(jasmin_add_bad_sector(&a, 1, 0, 7, 4), 0);
    ASSERT_EQ(jasmin_add_bad_sector(&a, 3, 1, 2, 9), 0);

    FILE* f1 = tmpfile(); FILE* f2 = tmpfile();
    ASSERT_TRUE(f1 && f2);
    ASSERT_TRUE(jasmin_save(&a, f1));
    long n1 = ftell(f1);
    rewind(f1);
    jasmin_load(&b, f1, (uint32_t)n1);
    jasmin_save(&b, f2);
    static unsigned char s1[512], s2[512];
    long m1 = jas_bytes(f1, s1, sizeof(s1));
    long m2 = jas_bytes(f2, s2, sizeof(s2));
    fclose(f1); fclose(f2);
    ASSERT_TRUE(m1 > 0);
    ASSERT_EQ(m2, m1);
    ASSERT_EQ(memcmp(s1, s2, (size_t)m1), 0);

    /* The FDC is re-pointed to the disk of the restored drive, map included. */
    ASSERT_EQ(b.drive, 2);
    ASSERT_TRUE(b.fdc.disk_data == img[2]);
    ASSERT_EQ(b.fdc.side, 1);
    ASSERT_EQ(b.bad_map[3].count, 1);
    ASSERT_EQ(b.bad_map[3].entry[0].sector, 9);
}

/* Unknown version or truncated section: the current state is left untouched. */
TEST(test_jasmin_load_rejects_bad_section) {
    jasmin_t a, b;
    memset(&a, 0, sizeof(a)); memset(&b, 0, sizeof(b));
    jasmin_init(&a); jasmin_init(&b);
    a.drive = 3; a.romdis = true;
    FILE* fp = tmpfile();
    ASSERT_TRUE(fp != NULL);
    jasmin_save(&a, fp);
    long n = ftell(fp);
    rewind(fp);
    jasmin_load(&b, fp, 10);                              /* truncated */
    ASSERT_EQ(b.drive, 0);
    rewind(fp); fputc(JASMIN_SAVE_VERSION + 1, fp);       /* unknown version */
    rewind(fp);
    jasmin_load(&b, fp, (uint32_t)n);
    ASSERT_EQ(b.drive, 0);
    ASSERT_FALSE(b.romdis);
    fclose(fp);
}

int main(void) {
    printf("Jasmin disk interface tests\n");
    printf("═══════════════════════════════════════════════════════\n");
    RUN(test_emu_disk_helpers_follow_active_iface);
    RUN(test_emu_disk_wire_routes_to_active_iface);
    RUN(test_jasmin_bad_sector_injection);
    RUN(test_jasmin_side_select_double_sided);
    RUN(test_jasmin_guest_write_persists);
    RUN(test_jasmin_save_load_restores_every_field);
    RUN(test_jasmin_load_rejects_bad_section);
    printf("═══════════════════════════════════════════════════════\n");
    printf("  %d passed, %d failed\n", tests_passed, tests_failed);
    return tests_failed == 0 ? 0 : 1;
}
