/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file test_picowifi.c
 * @brief PicoWiFiModemUSB backend unit tests
 * @author bmarty <bmarty@mailo.com>
 * @date 2026-06-13
 *
 * Drives the picowifi backend through its serial vtable (send AT chars,
 * drain the response from the RX ring) and asserts the v0.1.0/v0.2.0 AT
 * command behaviour: WiFi config, result-code formatting, S-registers, speed
 * dial, telnet, info, factory reset, error handling, and the v0.2.0 TLS
 * surface ($CV/$CA, '#' dial prefix, ATGET https). No real network is used
 * — only the hermetic command-parsing paths are exercised.
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "io/serial_backend.h"

/* Internal helper exposed for testing (serial_picowifi.c). */
bool pw_parse_daytime(const char* raw, char* out, size_t osz);

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) static void name(void)
#define RUN(name) do { \
    printf("  %-52s", #name); \
    name(); \
    tests_passed++; \
    printf("PASS\n"); \
} while(0)

#define ASSERT_TRUE(x) do { \
    if (!(x)) { \
        printf("FAIL\n    %s:%d: expected true\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_FALSE(x) do { \
    if ((x)) { \
        printf("FAIL\n    %s:%d: expected false\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_CONTAINS(hay, needle) do { \
    if (strstr((hay), (needle)) == NULL) { \
        printf("FAIL\n    %s:%d: \"%s\" not found in:\n      <<<%s>>>\n", \
               __FILE__, __LINE__, (needle), (hay)); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_NOT_CONTAINS(hay, needle) do { \
    if (strstr((hay), (needle)) != NULL) { \
        printf("FAIL\n    %s:%d: \"%s\" unexpectedly found in:\n      <<<%s>>>\n", \
               __FILE__, __LINE__, (needle), (hay)); \
        tests_failed++; return; \
    } \
} while(0)

/* ═══════════════════════════════════════════════════════════════════════
 *  Harness
 * ═══════════════════════════════════════════════════════════════════════ */

static serial_backend_t* pw;

#define PW_NVRAM_TEST "/tmp/phosphoric_pwnv_test.cfg"
#define PW_NVRAM_CA   "/tmp/phosphoric_pwnv_test.cfg.ca"   /* CA sidecar */

/* Fresh boot: wipe the test NVRAM (and CA sidecar) so each test starts clean. */
static void pw_setup(const char* ssid, const char* pass) {
    unlink(PW_NVRAM_TEST);
    unlink(PW_NVRAM_CA);
    pw = serial_backend_picowifi_create(ssid, pass);
    pw->open(pw);
}

/* Boot WITHOUT wiping NVRAM (used to verify persistence across a reboot). */
static void pw_setup_keepnvram(const char* ssid, const char* pass) {
    pw = serial_backend_picowifi_create(ssid, pass);
    pw->open(pw);
}

static void pw_teardown(void) {
    /* Mirror serial_backend_destroy() without linking serial_backend.c
     * (which pulls in the ACIA/digitelec deps): close frees the impl. */
    pw->close(pw);
    free(pw);
    pw = NULL;
}

/* Drain the RX ring into out. */
static void pw_drain(char* out, size_t outsz) {
    size_t i = 0;
    uint8_t b;
    while (i < outsz - 1 && pw->recv(pw, &b)) out[i++] = (char)b;
    out[i] = '\0';
}

/* Send a command line (CR appended), drain the response into out. */
static void pw_cmd(const char* line, char* out, size_t outsz) {
    for (const char* p = line; *p; p++) pw->send(pw, (uint8_t)*p);
    pw->send(pw, '\r');
    pw_drain(out, outsz);
}

/* Send a raw string verbatim (no CR appended) — used for the AT$CA= PEM
 * upload, which is segmented on LF by the firmware. */
static void pw_send_str(const char* s) {
    for (; *s; s++) pw->send(pw, (uint8_t)*s);
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Tests
 * ═══════════════════════════════════════════════════════════════════════ */

TEST(test_bare_at_ok) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_teardown();
}

TEST(test_ssid_set_and_query) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=MyNetwork", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_CONTAINS(r, "MyNetwork");
    pw_teardown();
}

TEST(test_ssid_preset_from_factory) {
    pw_setup("HomeWiFi", "secret");
    char r[512];
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_CONTAINS(r, "HomeWiFi");
    pw_teardown();
}

TEST(test_scan_lists_networks) {
    /* AT$SCAN lists nearby APs as "<index> <ssid>\t<O|S>", numbered from 1,
     * terminated by OK — mirroring the firmware doScan() format
     * (at_proprietary.h: printf("%d %s\t%c\r\n", ...), 'O'=open, 'S'=secured).
     * Uses the host nmcli, with a simulated fallback so the command always
     * yields a parseable, numbered list with security flags. */
    pw_setup(NULL, NULL);
    char r[1024];
    pw_cmd("AT$SCAN", r, sizeof(r));
    ASSERT_CONTAINS(r, "1 ");
    ASSERT_CONTAINS(r, "OK");
    /* Each entry must carry a TAB-separated security flag (O or S). */
    ASSERT_TRUE(strstr(r, "\tO") != NULL || strstr(r, "\tS") != NULL);
    pw_teardown();
}

TEST(test_password_query_shows_value) {
    /* Sprint 46: firmware shows the actual password (no masking). */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$PASS=hunter2", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$PASS?", r, sizeof(r));
    ASSERT_CONTAINS(r, "hunter2");
    pw_teardown();
}

TEST(test_mdns_default_picomodem) {
    /* Sprint 46: firmware factory default is "picomodem", not "espmodem". */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$MDNS?", r, sizeof(r));
    ASSERT_CONTAINS(r, "picomodem");
    pw_teardown();
}

TEST(test_baud_default_9600) {
    /* Sprint 46: firmware DEFAULT_SPEED is 9600. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SB?", r, sizeof(r));
    ASSERT_CONTAINS(r, "9600");
    pw_teardown();
}

TEST(test_location_default_computer_room) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$TTL?", r, sizeof(r));
    ASSERT_CONTAINS(r, "Computer Room");
    pw_teardown();
}

TEST(test_predefined_speed_dials) {
    /* Sprint 46: 3 factory speed dials (particles/altair/heatwave). */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT&Z0?", r, sizeof(r));
    ASSERT_CONTAINS(r, "particles");
    pw_cmd("AT&Z1?", r, sizeof(r));
    ASSERT_CONTAINS(r, "altair");
    pw_cmd("AT&Z2?", r, sizeof(r));
    ASSERT_CONTAINS(r, "heatwave");
    pw_teardown();
}

TEST(test_compound_command_line) {
    /* Sprint 46: "ATS0=7 NET0" applies BOTH settings, emits ONE OK. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATS0=7 NET0", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("ATS0?", r, sizeof(r));
    ASSERT_CONTAINS(r, "7");
    pw_cmd("ATNET?", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");
    pw_teardown();
}

TEST(test_compound_unknown_token_errors) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATE0 WXYZ Q0", r, sizeof(r));   /* WXYZ unknown → whole line ERROR */
    ASSERT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_numeric_result_codes_atv0) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATV0", r, sizeof(r));   /* switch to numeric */
    pw_cmd("AT", r, sizeof(r));     /* should answer "0" not "OK" */
    ASSERT_CONTAINS(r, "0");
    ASSERT_NOT_CONTAINS(r, "OK");
    pw_teardown();
}

TEST(test_quiet_mode_atq1) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATE0", r, sizeof(r));   /* no echo to keep response clean */
    pw_cmd("ATQ1", r, sizeof(r));   /* enable quiet */
    pw_cmd("AT", r, sizeof(r));     /* no result code at all */
    ASSERT_NOT_CONTAINS(r, "OK");
    ASSERT_NOT_CONTAINS(r, "0");
    pw_teardown();
}

TEST(test_echo_off_ate0) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATE0", r, sizeof(r));
    pw_cmd("AT$MDNS?", r, sizeof(r));
    /* With echo off the command itself must not be echoed back */
    ASSERT_NOT_CONTAINS(r, "MDNS");
    ASSERT_CONTAINS(r, "picomodem");
    pw_teardown();
}

TEST(test_s0_register) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATS0=3", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("ATS0?", r, sizeof(r));
    ASSERT_CONTAINS(r, "3");
    pw_teardown();
}

TEST(test_s2_escape_char) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATS2?", r, sizeof(r));
    ASSERT_CONTAINS(r, "43");   /* default '+' */
    pw_teardown();
}

TEST(test_telnet_mode) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATNET0", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("ATNET?", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");
    pw_teardown();
}

TEST(test_terminal_size) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$TTS=132x43", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$TTS?", r, sizeof(r));
    ASSERT_CONTAINS(r, "132x43");
    pw_teardown();
}

TEST(test_speed_dial_store_and_query) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT&Z0=bbs.example.com:6502,myBBS", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT&Z0?", r, sizeof(r));
    ASSERT_CONTAINS(r, "bbs.example.com:6502");
    ASSERT_CONTAINS(r, "myBBS");
    pw_teardown();
}

TEST(test_dial_speed_slot_empty) {
    pw_setup("Net", NULL);
    char r[512];
    pw_cmd("ATDS5", r, sizeof(r));   /* empty slot → ERROR (firmware) */
    ASSERT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_dial_no_ssid_no_carrier) {
    pw_setup(NULL, NULL);            /* no WiFi configured */
    char r[512];
    pw_cmd("ATDT example.com:23", r, sizeof(r));
    ASSERT_CONTAINS(r, "NO CARRIER");
    pw_teardown();
}

TEST(test_wifi_connect_status) {
    /* Sprint 46: ATC? returns numeric 0/1 (firmware), not text. */
    pw_setup("MyNet", "pw");
    char r[512];
    pw_cmd("ATC1", r, sizeof(r));    /* associate */
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("ATC?", r, sizeof(r));
    ASSERT_CONTAINS(r, "1");
    ASSERT_NOT_CONTAINS(r, "CONNECTED");
    pw_teardown();
}

TEST(test_wifi_connect_without_ssid_errors) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATC1", r, sizeof(r));
    ASSERT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_info_command) {
    pw_setup("Net", NULL);
    char r[512];
    pw_cmd("ATI", r, sizeof(r));
    ASSERT_CONTAINS(r, "PicoWiFiModemUSB");
    ASSERT_CONTAINS(r, "0.2.0");
    pw_teardown();
}

TEST(test_unknown_command_error) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATWXYZ", r, sizeof(r));
    ASSERT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_missing_at_prefix_error) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("HELLO", r, sizeof(r));
    ASSERT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_factory_reset_clears_ssid) {
    pw_setup("ToErase", "pw");
    char r[512];
    pw_cmd("AT&F", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_NOT_CONTAINS(r, "ToErase");
    pw_teardown();
}

TEST(test_save_profile_atw_ok) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT&W", r, sizeof(r));    /* save: no-op but must answer OK */
    ASSERT_CONTAINS(r, "OK");
    pw_teardown();
}

TEST(test_view_profile_atv_amp) {
    pw_setup("ViewNet", NULL);
    char r[512];
    pw_cmd("AT&V", r, sizeof(r));
    ASSERT_CONTAINS(r, "ViewNet");
    ASSERT_CONTAINS(r, "OK");
    pw_teardown();
}

TEST(test_repeat_last_command) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$MDNS?", r, sizeof(r));
    pw_cmd("A/", r, sizeof(r));      /* repeat → picomodem again */
    ASSERT_CONTAINS(r, "picomodem");
    pw_teardown();
}

TEST(test_atz_is_noop) {
    /* Sprint 46: firmware ATZ does NOT reset (would drop USB) — just OK.
     * So a prior ATV0 (numeric) stays in effect after ATZ. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATV0", r, sizeof(r));    /* numeric result codes */
    pw_cmd("ATZ", r, sizeof(r));     /* no-op */
    pw_cmd("AT", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");         /* still numeric, ATZ did not restore V1 */
    ASSERT_NOT_CONTAINS(r, "OK");
    pw_teardown();
}

TEST(test_baud_set_and_query) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SB=9600", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$SB?", r, sizeof(r));
    ASSERT_CONTAINS(r, "9600");
    pw_teardown();
}

TEST(test_flow_control_amp_k) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT&K1", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT&K?", r, sizeof(r));
    ASSERT_CONTAINS(r, "1");
    pw_teardown();
}

TEST(test_backend_type_tag) {
    pw_setup(NULL, NULL);
    ASSERT_TRUE(pw->type == SERIAL_BACKEND_PICOWIFI);
    ASSERT_FALSE(pw->connected(pw));  /* idle, no data connection */
    pw_teardown();
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Sprint 47 — Telnet integration tests (real localhost sockets)
 *
 *  These exercise the genuine data path: a loopback TCP listener stands in
 *  for the remote host; the backend dials it via ATDT and we verify the
 *  byte-level telnet transforms and IAC negotiation in both directions.
 * ═══════════════════════════════════════════════════════════════════════ */

static int g_listener = -1;
static int g_srv = -1;

static uint16_t tn_make_listener(void) {
    g_listener = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    sa.sin_port = 0;   /* ephemeral */
    int one = 1;
    setsockopt(g_listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    bind(g_listener, (struct sockaddr*)&sa, sizeof(sa));
    listen(g_listener, 1);
    socklen_t sl = sizeof(sa);
    getsockname(g_listener, (struct sockaddr*)&sa, &sl);
    return ntohs(sa.sin_port);
}

/* Set up backend, dial the listener with the given prefix (""/"="/"-"/"+"),
 * and accept the server side into g_srv. */
static void tn_connect(const char* prefix) {
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[80], r[512];
    snprintf(cmd, sizeof(cmd), "ATDT%s127.0.0.1:%u", prefix, port);
    pw_cmd(cmd, r, sizeof(r));            /* dials → CONNECT */
    g_srv = accept(g_listener, NULL, NULL);
    int fl = fcntl(g_srv, F_GETFL, 0);
    fcntl(g_srv, F_SETFL, fl | O_NONBLOCK);
}

static void tn_disconnect(void) {
    if (g_srv >= 0) { close(g_srv); g_srv = -1; }
    if (g_listener >= 0) { close(g_listener); g_listener = -1; }
    pw_teardown();
}

/* Read from the server side, ACCUMULATING until the burst is complete. A
 * single read() may return only the first TCP segment: the Oric sends its
 * bytes one send() at a time, and while Linux loopback coalesces them into one
 * read, macOS can deliver them across several segments. Keep reading (g_srv is
 * non-blocking → EAGAIN when idle) until no more data arrives for ~5 ms after
 * having received some, so multi-segment outbound data is fully captured. */
static int tn_srv_read(uint8_t* buf, int max) {
    int total = 0, idle = 0;
    for (int t = 0; t < 8000 && total < max; t++) {
        ssize_t r = read(g_srv, buf + total, (size_t)(max - total));
        if (r > 0)       { total += (int)r; idle = 0; }
        else if (r == 0) break;                                  /* EOF */
        else { if (total > 0 && ++idle >= 50) break; usleep(100); }
    }
    return total;
}

/* Pump the backend's recv (reads socket → telnet → rx) draining data bytes
 * destined for the Oric into out. Sleep on an empty poll (see tn_srv_read):
 * spinning without a wait drains before macOS loopback delivers the bytes. */
static int tn_drain_oric(uint8_t* out, int max) {
    int i = 0; uint8_t b;
    for (int t = 0; t < 4000 && i < max; t++) {
        if (pw->recv(pw, &b)) out[i++] = b;
        else                  usleep(100);
    }
    return i;
}

/* Send a run of data-mode bytes from the Oric to the line. */
static void tn_oric_send(const uint8_t* buf, int len) {
    for (int i = 0; i < len; i++) pw->send(pw, buf[i]);
}

TEST(test_telnet_outbound_cr_nul) {
    /* REAL telnet ('=') : CR → CR NUL on the wire. */
    tn_connect("=");
    uint8_t in[] = { 'A', 0x0D, 'B' };
    tn_oric_send(in, 3);
    uint8_t got[16];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 4);
    ASSERT_TRUE(got[0] == 'A' && got[1] == 0x0D && got[2] == 0x00 && got[3] == 'B');
    tn_disconnect();
}

TEST(test_telnet_outbound_iac_double) {
    /* IAC (0xFF) is doubled in both real and fake modes. */
    tn_connect("=");
    uint8_t in[] = { 0xFF };
    tn_oric_send(in, 1);
    uint8_t got[8];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 2);
    ASSERT_TRUE(got[0] == 0xFF && got[1] == 0xFF);
    tn_disconnect();
}

TEST(test_telnet_net0_transparent) {
    /* NET0 ('-') : byte-transparent — no CR+NUL, no IAC doubling.
     * This is the mode required for clean Videotex/Minitel streams. */
    tn_connect("-");
    uint8_t in[] = { 'A', 0x0D, 'B', 0xFF };
    tn_oric_send(in, 4);
    uint8_t got[16];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 4);
    ASSERT_TRUE(got[0] == 'A' && got[1] == 0x0D && got[2] == 'B' && got[3] == 0xFF);
    tn_disconnect();
}

TEST(test_telnet_fake_no_cr_nul) {
    /* FAKE ('+') : IAC doubled but CR is NOT followed by NUL. */
    tn_connect("+");
    uint8_t in[] = { 0x0D, 0xFF };
    tn_oric_send(in, 2);
    uint8_t got[16];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 3);
    ASSERT_TRUE(got[0] == 0x0D && got[1] == 0xFF && got[2] == 0xFF);
    tn_disconnect();
}

TEST(test_telnet_inbound_do_ttype_will) {
    /* Server: IAC DO TTYPE → backend replies IAC WILL TTYPE; the sequence
     * is stripped from the Oric stream. */
    tn_connect("=");
    uint8_t req[] = { 255, 253, 24 };   /* IAC DO TTYPE */
    (void)!write(g_srv, req, 3);
    uint8_t oric[16];
    int no = tn_drain_oric(oric, sizeof(oric));
    ASSERT_TRUE(no == 0);               /* nothing leaks to the Oric */
    uint8_t got[8];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 3);
    ASSERT_TRUE(got[0] == 255 && got[1] == 251 && got[2] == 24); /* IAC WILL TTYPE */
    tn_disconnect();
}

TEST(test_telnet_inbound_will_naws_dont) {
    /* Server: IAC WILL NAWS → backend replies IAC DONT NAWS. */
    tn_connect("=");
    uint8_t req[] = { 255, 251, 31 };   /* IAC WILL NAWS */
    (void)!write(g_srv, req, 3);
    uint8_t oric[16];
    (void)tn_drain_oric(oric, sizeof(oric));
    uint8_t got[8];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 3);
    ASSERT_TRUE(got[0] == 255 && got[1] == 254 && got[2] == 31); /* IAC DONT NAWS */
    tn_disconnect();
}

TEST(test_telnet_inbound_cr_nul_filter) {
    /* REAL : incoming CR NUL is delivered to the Oric as a bare CR. */
    tn_connect("=");
    uint8_t data[] = { 'A', 0x0D, 0x00, 'B' };
    (void)!write(g_srv, data, 4);
    uint8_t oric[16];
    int n = tn_drain_oric(oric, sizeof(oric));
    ASSERT_TRUE(n == 3);
    ASSERT_TRUE(oric[0] == 'A' && oric[1] == 0x0D && oric[2] == 'B');
    tn_disconnect();
}

TEST(test_telnet_inbound_iac_iac_data) {
    /* IAC IAC in the stream is a single literal 0xFF data byte. */
    tn_connect("=");
    uint8_t data[] = { 'X', 255, 255, 'Y' };
    (void)!write(g_srv, data, 4);
    uint8_t oric[16];
    int n = tn_drain_oric(oric, sizeof(oric));
    ASSERT_TRUE(n == 3);
    ASSERT_TRUE(oric[0] == 'X' && oric[1] == 0xFF && oric[2] == 'Y');
    tn_disconnect();
}

TEST(test_rx_flow_control_no_loss_over_ring_size) {
    /* Regression (ProphetOric report, 2026-09-17): a peer pushing far more
     * than the 64KB RX ring while the Oric drains slowly used to lose every
     * byte beyond the ring, silently. The backend must now leave unread data
     * in the kernel so the TCP window throttles the peer, like the Pico. */
    tn_connect("-");                                  /* raw stream, no telnet */
    enum { TOTAL = 200 * 1024 };
    uint8_t* out = malloc(TOTAL);
    ASSERT_TRUE(out != NULL);
    int sent = 0, got = 0; uint8_t b;
    for (int spin = 0; spin < 2000000 && got < TOTAL; spin++) {
        if (sent < TOTAL) {                           /* peer: blast as fast as it can */
            uint8_t chunk[4096]; int n = 0;
            while (n < (int)sizeof(chunk) && sent + n < TOTAL) { chunk[n] = (uint8_t)((sent + n) % 251); n++; }
            ssize_t w = write(g_srv, chunk, (size_t)n);
            if (w > 0) sent += (int)w;                /* EAGAIN = window closed: fine */
        }
        /* Oric: ~one byte per spin, far slower than the peer. */
        if (pw->recv(pw, &b)) out[got++] = b;
    }
    ASSERT_TRUE(sent == TOTAL);
    ASSERT_TRUE(got == TOTAL);
    for (int i = 0; i < TOTAL; i++)
        if (out[i] != (uint8_t)(i % 251)) { printf("FAIL\n    byte %d: %02X\n", i, out[i]); tests_failed++; free(out); tn_disconnect(); return; }
    free(out);
    tn_disconnect();
}

TEST(test_telnet_inbound_ayt_response) {
    /* Server sends IAC AYT → backend answers "\r\n[Yes]\r\n" on the line. */
    tn_connect("=");
    uint8_t req[] = { 255, 246 };       /* IAC AYT */
    (void)!write(g_srv, req, 2);
    uint8_t oric[16];
    (void)tn_drain_oric(oric, sizeof(oric));
    uint8_t got[32];
    int n = tn_srv_read(got, sizeof(got));
    got[n > 0 ? n : 0] = '\0';
    ASSERT_CONTAINS((char*)got, "[Yes]");
    tn_disconnect();
}

TEST(test_net0_default_via_atnet) {
    /* ATNET0 then dial with no prefix → session inherits NET0 (transparent).
     * Mirrors the Minitel/OricTel use case (Videotex byte stream intact). */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[80], r[512];
    pw_cmd("ATNET0", r, sizeof(r));
    snprintf(cmd, sizeof(cmd), "ATDT127.0.0.1:%u", port);
    pw_cmd(cmd, r, sizeof(r));
    g_srv = accept(g_listener, NULL, NULL);
    int fl = fcntl(g_srv, F_GETFL, 0);
    fcntl(g_srv, F_SETFL, fl | O_NONBLOCK);
    uint8_t in[] = { 0x0D, 0xFF };       /* would be transformed if telnet on */
    tn_oric_send(in, 2);
    uint8_t got[8];
    int n = tn_srv_read(got, sizeof(got));
    ASSERT_TRUE(n == 2);
    ASSERT_TRUE(got[0] == 0x0D && got[1] == 0xFF);
    tn_disconnect();
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Sprint 48 — real network commands (ATGET / ATRD), alias & 7-digit dial,
 *  AT$BM, +++ escape
 * ═══════════════════════════════════════════════════════════════════════ */

/* Drive +++ from data mode back to command mode (poll-count guard: pump
 * recv between each '+' so the silence threshold is met each time). */
static void tn_escape_to_command(void) {
    uint8_t b;
    for (int k = 0; k < 3; k++) {
        for (int i = 0; i < 80; i++) pw->recv(pw, &b);
        pw->send(pw, '+');
    }
    for (int i = 0; i < 40; i++) pw->recv(pw, &b);   /* drain the OK */
}

TEST(test_nist_daytime_parse) {
    char out[64];
    bool ok = pw_parse_daytime("59999 26-06-13 12:34:56 50 0 0 123.4 UTC(NIST) *",
                               out, sizeof(out));
    ASSERT_TRUE(ok);
    ASSERT_CONTAINS(out, "26-06-13 12:34:56");
}

TEST(test_nist_daytime_parse_garbage) {
    char out[64];
    ASSERT_FALSE(pw_parse_daytime("xx", out, sizeof(out)));
}

TEST(test_busy_message_default) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$BM?", r, sizeof(r));
    ASSERT_CONTAINS(r, "busy");
    pw_teardown();
}

TEST(test_busy_message_set) {
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$BM=Closed for maintenance", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$BM?", r, sizeof(r));
    ASSERT_CONTAINS(r, "Closed for maintenance");
    pw_teardown();
}

TEST(test_atget_http_request) {
    /* ATGET issues a real HTTP/1.1 GET; the response streams raw to Oric. */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[96], r[512];
    snprintf(cmd, sizeof(cmd), "ATGET http://127.0.0.1:%u/hello", port);
    pw_cmd(cmd, r, sizeof(r));
    ASSERT_CONTAINS(r, "CONNECT");
    g_srv = accept(g_listener, NULL, NULL);
    int fl = fcntl(g_srv, F_GETFL, 0);
    fcntl(g_srv, F_SETFL, fl | O_NONBLOCK);

    uint8_t req[300];
    int n = tn_srv_read(req, sizeof(req) - 1);
    req[n > 0 ? n : 0] = '\0';
    ASSERT_CONTAINS((char*)req, "GET /hello HTTP/1.1");
    ASSERT_CONTAINS((char*)req, "Host: 127.0.0.1");
    ASSERT_CONTAINS((char*)req, "Connection: close");

    const char* resp = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nHELLO";
    (void)!write(g_srv, resp, strlen(resp));
    uint8_t oric[256];
    int no = tn_drain_oric(oric, sizeof(oric) - 1);
    oric[no > 0 ? no : 0] = '\0';
    ASSERT_CONTAINS((char*)oric, "200 OK");
    ASSERT_CONTAINS((char*)oric, "HELLO");
    tn_disconnect();
}

/* ═══════════════════════════════════════════════════════════════════════
 *  loci-webdisk (architecture B) — ATDISKRD / ATDISKWR raw disk transfer
 *
 *  These exercise the real network path against a forked one-shot HTTP server
 *  (a stand-in for disk_server.py). ATDISKRD is synchronous inside the command
 *  handler, so the responder must run concurrently → we fork it.
 * ═══════════════════════════════════════════════════════════════════════ */

/* Drain the RX ring into a byte buffer (binary-safe, unlike pw_drain's C-str);
 * pumps recv() a bounded number of times to let a synchronous handler settle. */
static int pw_drain_bytes(uint8_t* out, int max) {
    int i = 0; uint8_t b;
    for (int t = 0; t < 8000 && i < max; t++) {
        if (pw->recv(pw, &b)) out[i++] = b;
    }
    return i;
}

TEST(test_atdiskrd_e2e) {
    /* ATDISKRD http://host/path → GET, strip HTTP, stream body to the Oric as
     * \r\n+DISK:<len>\r\n<bytes> then OK. The forked server returns 7 raw bytes. */
    uint16_t port = tn_make_listener();
    const char* body = "SEDORIC";                 /* 7 bytes, no embedded NUL */

    pid_t pid = fork();
    ASSERT_TRUE(pid >= 0);
    if (pid == 0) {                               /* child: one HTTP response */
        int c = accept(g_listener, NULL, NULL);
        if (c >= 0) {
            char req[512]; (void)!read(c, req, sizeof(req));
            char resp[128];
            int rn = snprintf(resp, sizeof(resp),
                "HTTP/1.1 200 OK\r\nContent-Length: 7\r\nConnection: close\r\n\r\n%s",
                body);
            (void)!write(c, resp, (size_t)rn);
            close(c);
        }
        _exit(0);
    }

    pw_setup("Net", NULL);
    char cmd[128];
    snprintf(cmd, sizeof(cmd),
             "ATDISKRD http://127.0.0.1:%u/disk/test.dsk?offset=0&len=7", port);
    for (const char* p = cmd; *p; p++) pw->send(pw, (uint8_t)*p);
    pw->send(pw, '\r');                           /* synchronous fetch happens here */

    uint8_t out[512];
    int n = pw_drain_bytes(out, sizeof(out));
    waitpid(pid, NULL, 0);
    close(g_listener); g_listener = -1;

    ASSERT_TRUE(memmem(out, (size_t)n, "+DISK:7", 7) != NULL);      /* length marker */
    ASSERT_TRUE(memmem(out, (size_t)n, body, 7) != NULL);          /* raw disk bytes */
    ASSERT_TRUE(memmem(out, (size_t)n, "OK", 2) != NULL);          /* result code */
    pw_teardown();
}

TEST(test_atdiskwr_e2e) {
    /* ATDISKWR http://host/path?offset=&len=8 → capture 8 raw bytes from the
     * Oric, PUT them as the body, reply OK. Child echoes the request via a pipe
     * so we can assert the method, Content-Length and the exact body sent. */
    uint16_t port = tn_make_listener();
    const uint8_t body[8] = { 'W','E','B','D','I','S','K','!' };

    int rep[2];
    ASSERT_TRUE(pipe(rep) == 0);
    pid_t pid = fork();
    ASSERT_TRUE(pid >= 0);
    if (pid == 0) {                               /* child: read PUT, reply 200 */
        close(rep[0]);
        int c = accept(g_listener, NULL, NULL);
        char buf[1024]; int total = 0;
        if (c >= 0) {
            for (int t = 0; t < 200 && total < (int)sizeof(buf); t++) {
                ssize_t r = read(c, buf + total, sizeof(buf) - (size_t)total);
                if (r > 0) total += (int)r;
                char* hdr_end = memmem(buf, (size_t)total, "\r\n\r\n", 4);
                if (hdr_end && (buf + total) - (hdr_end + 4) >= 8) break;
                if (r == 0) break;
            }
            const char* resp =
                "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
            (void)!write(c, resp, strlen(resp));
            close(c);
        }
        (void)!write(rep[1], buf, (size_t)total);
        close(rep[1]);
        _exit(0);
    }
    close(rep[1]);

    pw_setup("Net", NULL);
    char cmd[128];
    snprintf(cmd, sizeof(cmd),
             "ATDISKWR http://127.0.0.1:%u/disk/test.dsk?offset=512&len=8", port);
    for (const char* p = cmd; *p; p++) pw->send(pw, (uint8_t)*p);
    pw->send(pw, '\r');                           /* → raw-capture mode */
    for (int i = 0; i < 8; i++) pw->send(pw, body[i]);   /* 8th byte triggers PUT */

    uint8_t out[256];
    int n = pw_drain_bytes(out, sizeof(out));

    char got[1024];
    int gn = (int)read(rep[0], got, sizeof(got) - 1);
    if (gn < 0) gn = 0;
    got[gn] = '\0';
    waitpid(pid, NULL, 0);
    close(rep[0]); close(g_listener); g_listener = -1;

    ASSERT_TRUE(memmem(out, (size_t)n, "OK", 2) != NULL);              /* PUT ok */
    ASSERT_TRUE(memmem(got, (size_t)gn, "PUT /disk/test.dsk", 18) != NULL);
    ASSERT_TRUE(memmem(got, (size_t)gn, "Content-Length: 8", 17) != NULL);
    ASSERT_TRUE(memmem(got, (size_t)gn, body, 8) != NULL);            /* exact body */
    pw_teardown();
}

TEST(test_dial_by_alias) {
    /* AT&Z5 = localhost,mybbs ; ATDTmybbs resolves the alias and connects. */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[96], r[512];
    snprintf(cmd, sizeof(cmd), "AT&Z5=127.0.0.1:%u,mybbs", port);
    pw_cmd(cmd, r, sizeof(r));
    pw_cmd("ATDTmybbs", r, sizeof(r));
    ASSERT_CONTAINS(r, "CONNECT");
    g_srv = accept(g_listener, NULL, NULL);
    ASSERT_TRUE(g_srv >= 0);
    tn_disconnect();
}

TEST(test_dial_seven_digits) {
    /* ATDT7777777 → speed-dial slot 7. */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[96], r[512];
    snprintf(cmd, sizeof(cmd), "AT&Z7=127.0.0.1:%u,x", port);
    pw_cmd(cmd, r, sizeof(r));
    pw_cmd("ATDT7777777", r, sizeof(r));
    ASSERT_CONTAINS(r, "CONNECT");
    g_srv = accept(g_listener, NULL, NULL);
    ASSERT_TRUE(g_srv >= 0);
    tn_disconnect();
}

TEST(test_dial_host_starting_with_p) {
    /* Regression (OricTel report #2): a bare ATD to a host whose name starts
     * with 'p'/'t' must NOT be mistaken for a DP/DT pulse/tone modifier.
     * Before the fix, "ATDpbbs" parsed as DP + "bbs" (pulse-dial of "bbs"),
     * losing the leading 'p' and failing alias resolution. The dial modifier
     * is now matched case-sensitively (uppercase T/P only), so the lowercase
     * 'p' stays part of the hostname. */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[96], r[512];
    snprintf(cmd, sizeof(cmd), "AT&Z5=127.0.0.1:%u,pbbs", port);
    pw_cmd(cmd, r, sizeof(r));
    pw_cmd("ATDpbbs", r, sizeof(r));     /* bare D, host keeps its 'p' */
    ASSERT_CONTAINS(r, "CONNECT");
    g_srv = accept(g_listener, NULL, NULL);
    ASSERT_TRUE(g_srv >= 0);
    tn_disconnect();
}

TEST(test_dial_uppercase_modifier_keeps_host) {
    /* The uppercase ATDT modifier is still consumed, and a host that then
     * starts with 'p' (e.g. "ATDTpbbs") keeps its leading letter. */
    uint16_t port = tn_make_listener();
    pw_setup("Net", NULL);
    char cmd[96], r[512];
    snprintf(cmd, sizeof(cmd), "AT&Z5=127.0.0.1:%u,pbbs", port);
    pw_cmd(cmd, r, sizeof(r));
    pw_cmd("ATDTpbbs", r, sizeof(r));    /* T stripped, "pbbs" dialed */
    ASSERT_CONTAINS(r, "CONNECT");
    g_srv = accept(g_listener, NULL, NULL);
    ASSERT_TRUE(g_srv >= 0);
    tn_disconnect();
}

TEST(test_plus_plus_plus_escape) {
    /* +++ returns to command mode without dropping carrier; ATO resumes. */
    tn_connect("-");
    ASSERT_TRUE(pw->connected(pw));
    tn_escape_to_command();
    ASSERT_FALSE(pw->connected(pw));     /* command mode, socket still open */
    char r[256];
    pw_cmd("ATO", r, sizeof(r));
    ASSERT_CONTAINS(r, "CONNECT");
    tn_disconnect();
}

TEST(test_atrd_in_call_errors) {
    /* ATRD while a call is up → ERROR (firmware refuses). */
    tn_connect("-");
    tn_escape_to_command();
    char r[256];
    pw_cmd("ATRD", r, sizeof(r));
    ASSERT_CONTAINS(r, "ERROR");
    tn_disconnect();
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Sprint 49 — NVRAM persistence + boot
 * ═══════════════════════════════════════════════════════════════════════ */

TEST(test_nvram_roundtrip) {
    /* Save settings, reboot (keeping NVRAM), verify they persist. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=StoredNet", r, sizeof(r));
    pw_cmd("AT$SB=2400", r, sizeof(r));
    pw_cmd("AT&W", r, sizeof(r));        /* persist */
    ASSERT_CONTAINS(r, "OK");
    pw_teardown();

    pw_setup_keepnvram(NULL, NULL);      /* reboot */
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_CONTAINS(r, "StoredNet");
    pw_cmd("AT$SB?", r, sizeof(r));
    ASSERT_CONTAINS(r, "2400");
    pw_teardown();
}

TEST(test_nvram_not_saved_without_atw) {
    /* A change not followed by AT&W must not survive a reboot. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=Ephemeral", r, sizeof(r));   /* no AT&W */
    pw_teardown();

    pw_setup_keepnvram(NULL, NULL);
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_NOT_CONTAINS(r, "Ephemeral");
    pw_teardown();
}

TEST(test_view_stored_vs_current) {
    /* AT&V0 = current, AT&V1 = stored. After AT&W then a change, they
     * must differ on the changed field (S0). */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATS0=2", r, sizeof(r));
    pw_cmd("AT&W", r, sizeof(r));        /* store S0=2 */
    pw_cmd("ATS0=9", r, sizeof(r));      /* current S0=9, stored still 2 */
    pw_cmd("AT&V0", r, sizeof(r));
    ASSERT_CONTAINS(r, "S0=9");
    pw_cmd("AT&V1", r, sizeof(r));
    ASSERT_CONTAINS(r, "S0=2");
    pw_teardown();
}

TEST(test_cli_creds_override_nvram) {
    /* NVRAM stores one SSID; a CLI-provided SSID wins at boot. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=FromNvram", r, sizeof(r));
    pw_cmd("AT&W", r, sizeof(r));
    pw_teardown();

    pw_setup_keepnvram("FromCli", NULL); /* CLI ssid overrides */
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_CONTAINS(r, "FromCli");
    ASSERT_NOT_CONTAINS(r, "FromNvram");
    pw_teardown();
}

TEST(test_boot_autoexec) {
    /* AT$AE stores a command run at the next boot. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATS0=0", r, sizeof(r));
    pw_cmd("AT$AE=ATS0=9", r, sizeof(r));  /* boot command sets S0=9 */
    pw_cmd("AT&W", r, sizeof(r));
    pw_teardown();

    pw_setup_keepnvram(NULL, NULL);        /* boot runs ATS0=9 */
    pw_cmd("ATS0?", r, sizeof(r));
    ASSERT_CONTAINS(r, "9");
    pw_teardown();
}

TEST(test_factory_reset_persists) {
    /* AT&F resets AND writes defaults to NVRAM. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=Doomed", r, sizeof(r));
    pw_cmd("AT&W", r, sizeof(r));
    pw_cmd("AT&F", r, sizeof(r));           /* factory + persist */
    pw_teardown();

    pw_setup_keepnvram(NULL, NULL);
    pw_cmd("AT$SSID?", r, sizeof(r));
    ASSERT_NOT_CONTAINS(r, "Doomed");
    pw_teardown();
}

TEST(test_boot_wifi_auto_associate) {
    /* With a stored SSID, the link comes up at boot (ATC? = 1). */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT$SSID=AutoNet", r, sizeof(r));
    pw_cmd("AT&W", r, sizeof(r));
    pw_teardown();

    pw_setup_keepnvram(NULL, NULL);
    pw_cmd("ATC?", r, sizeof(r));
    ASSERT_CONTAINS(r, "1");
    pw_teardown();
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Real host-network bridge (read-only, opt-in via env var)
 * ═══════════════════════════════════════════════════════════════════════ */

TEST(test_realnet_ati_reports_host_ip) {
    setenv("PHOSPHORIC_PICOWIFI_REALNET", "1", 1);
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATI", r, sizeof(r));
    ASSERT_CONTAINS(r, "(host)");          /* real-state markers */
    ASSERT_CONTAINS(r, ".");               /* an IPv4 address */
    ASSERT_NOT_CONTAINS(r, "simulated");
    pw_teardown();
    unsetenv("PHOSPHORIC_PICOWIFI_REALNET");
}

TEST(test_realnet_atc_returns_real_status) {
    setenv("PHOSPHORIC_PICOWIFI_REALNET", "1", 1);
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATC?", r, sizeof(r));
    ASSERT_TRUE(strchr(r, '0') != NULL || strchr(r, '1') != NULL);
    pw_teardown();
    unsetenv("PHOSPHORIC_PICOWIFI_REALNET");
}

TEST(test_realnet_off_is_simulated) {
    /* Default (no env) keeps the simulated IP — regression guard. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("ATI", r, sizeof(r));
    ASSERT_CONTAINS(r, "simulated");
    pw_teardown();
}

/* ── Sprint 60 — firmware v0.2.0 TLS surface (hermetic; no real network) ── */

TEST(test_tls_cv_default_off) {
    /* AT$CV? reports 0 at factory (insecure default). */
    pw_setup(NULL, NULL);
    char r[256];
    pw_cmd("AT$CV?", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");
    pw_cmd("AT$CA?", r, sizeof(r));
    ASSERT_CONTAINS(r, "CA: 0 bytes");
    pw_teardown();
}

TEST(test_tls_cv1_without_ca_errors) {
    /* AT$CV1 is refused without a stored CA (would be silently insecure). */
    pw_setup(NULL, NULL);
    char r[256];
    pw_cmd("AT$CV1", r, sizeof(r));
    ASSERT_CONTAINS(r, "ERROR");
    pw_cmd("AT$CV?", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");
    pw_teardown();
}

TEST(test_tls_ca_upload_enables_verify) {
    /* AT$CA= uploads a PEM (ended by a sole '.'), AT$CV1 then succeeds, and
     * AT$CA- clears both the CA and the verification flag. */
    pw_setup(NULL, NULL);
    char r[1024];
    pw_cmd("AT$CA=", r, sizeof(r));
    ASSERT_CONTAINS(r, "PEM");
    pw_send_str("-----BEGIN CERTIFICATE-----\n"
                "MIIBdummyBase64Content==\n"
                "-----END CERTIFICATE-----\n"
                ".\n");
    pw_drain(r, sizeof(r));
    ASSERT_CONTAINS(r, "CA stored");
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$CA?", r, sizeof(r));
    ASSERT_NOT_CONTAINS(r, "CA: 0 bytes");
    pw_cmd("AT$CV1", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$CV?", r, sizeof(r));
    ASSERT_CONTAINS(r, "1");
    /* Delete the CA → verification can no longer stand. */
    pw_cmd("AT$CA-", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT$CA?", r, sizeof(r));
    ASSERT_CONTAINS(r, "CA: 0 bytes");
    pw_cmd("AT$CV?", r, sizeof(r));
    ASSERT_CONTAINS(r, "0");
    pw_teardown();
}

TEST(test_tls_dial_prefix_routed) {
    /* The '#' dial prefix is accepted and routed through the dialer; with no
     * SSID and no real-net bridge, association fails → NO CARRIER (proves the
     * prefix is parsed, not rejected as an unknown command). */
    pw_setup(NULL, NULL);
    char r[256];
    pw_cmd("ATDT#example.com:443", r, sizeof(r));
    ASSERT_CONTAINS(r, "NO CARRIER");
    ASSERT_NOT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_tls_atget_https_routed) {
    /* ATGET https://... is parsed (TLS, port 443) and dialed; hermetic NO
     * CARRIER without an SSID. */
    pw_setup(NULL, NULL);
    char r[256];
    pw_cmd("ATGET https://example.com/", r, sizeof(r));
    ASSERT_CONTAINS(r, "NO CARRIER");
    ASSERT_NOT_CONTAINS(r, "ERROR");
    pw_teardown();
}

TEST(test_help_lists_tls_commands) {
    /* AT? advertises the new $CV/$CA verbs. */
    pw_setup(NULL, NULL);
    char r[512];
    pw_cmd("AT?", r, sizeof(r));
    ASSERT_CONTAINS(r, "$CV");
    ASSERT_CONTAINS(r, "$CA");
    pw_teardown();
}

TEST(test_tls_ca_persists_across_reboot) {
    /* The CA survives a reboot on its own (firmware ca.pem, written on AT$CA=,
     * independent of AT&W); tlsVerify survives once committed with AT&W. */
    pw_setup(NULL, NULL);
    char r[1024];
    pw_cmd("AT$CA=", r, sizeof(r));
    pw_send_str("-----BEGIN CERTIFICATE-----\nMIIBpersisted==\n"
                "-----END CERTIFICATE-----\n.\n");
    pw_drain(r, sizeof(r));
    ASSERT_CONTAINS(r, "CA stored");
    pw_cmd("AT$CV1", r, sizeof(r));
    ASSERT_CONTAINS(r, "OK");
    pw_cmd("AT&W", r, sizeof(r));            /* persist tlsVerify */
    ASSERT_CONTAINS(r, "OK");
    pw_teardown();

    /* Reboot WITHOUT wiping NVRAM: CA + verification must come back. */
    pw_setup_keepnvram(NULL, NULL);
    pw_cmd("AT$CA?", r, sizeof(r));
    ASSERT_NOT_CONTAINS(r, "CA: 0 bytes");
    pw_cmd("AT$CV?", r, sizeof(r));
    ASSERT_CONTAINS(r, "1");
    /* AT$CA- clears the sidecar so a later reboot sees no CA. */
    pw_cmd("AT$CA-", r, sizeof(r));
    pw_teardown();
    pw_setup_keepnvram(NULL, NULL);
    pw_cmd("AT$CA?", r, sizeof(r));
    ASSERT_CONTAINS(r, "CA: 0 bytes");
    pw_teardown();
    unlink(PW_NVRAM_CA);
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Runner
 * ═══════════════════════════════════════════════════════════════════════ */

int main(void) {
    /* Keep all tests hermetic: NVRAM lives in a temp file, never the user's
     * real home config. */
    setenv("PHOSPHORIC_PICOWIFI_NVRAM", PW_NVRAM_TEST, 1);
    unlink(PW_NVRAM_TEST);

    printf("\n");
    printf("═══════════════════════════════════════════════════════\n");
    printf("  PicoWiFiModemUSB Backend Tests\n");
    printf("═══════════════════════════════════════════════════════\n\n");

    RUN(test_bare_at_ok);
    RUN(test_ssid_set_and_query);
    RUN(test_ssid_preset_from_factory);
    RUN(test_scan_lists_networks);
    RUN(test_password_query_shows_value);
    RUN(test_mdns_default_picomodem);
    RUN(test_baud_default_9600);
    RUN(test_location_default_computer_room);
    RUN(test_predefined_speed_dials);
    RUN(test_compound_command_line);
    RUN(test_compound_unknown_token_errors);
    RUN(test_numeric_result_codes_atv0);
    RUN(test_quiet_mode_atq1);
    RUN(test_echo_off_ate0);
    RUN(test_s0_register);
    RUN(test_s2_escape_char);
    RUN(test_telnet_mode);
    RUN(test_terminal_size);
    RUN(test_speed_dial_store_and_query);
    RUN(test_dial_speed_slot_empty);
    RUN(test_dial_no_ssid_no_carrier);
    RUN(test_wifi_connect_status);
    RUN(test_wifi_connect_without_ssid_errors);
    RUN(test_info_command);
    RUN(test_unknown_command_error);
    RUN(test_missing_at_prefix_error);
    RUN(test_factory_reset_clears_ssid);
    RUN(test_save_profile_atw_ok);
    RUN(test_view_profile_atv_amp);
    RUN(test_repeat_last_command);
    RUN(test_atz_is_noop);
    RUN(test_baud_set_and_query);
    RUN(test_flow_control_amp_k);
    RUN(test_backend_type_tag);

    /* Sprint 47 — telnet protocol (localhost socket integration) */
    RUN(test_telnet_outbound_cr_nul);
    RUN(test_telnet_outbound_iac_double);
    RUN(test_telnet_net0_transparent);
    RUN(test_telnet_fake_no_cr_nul);
    RUN(test_telnet_inbound_do_ttype_will);
    RUN(test_telnet_inbound_will_naws_dont);
    RUN(test_telnet_inbound_cr_nul_filter);
    RUN(test_telnet_inbound_iac_iac_data);
    RUN(test_rx_flow_control_no_loss_over_ring_size);
    RUN(test_telnet_inbound_ayt_response);
    RUN(test_net0_default_via_atnet);

    /* Sprint 48 — real network commands */
    RUN(test_nist_daytime_parse);
    RUN(test_nist_daytime_parse_garbage);
    RUN(test_busy_message_default);
    RUN(test_busy_message_set);
    RUN(test_atget_http_request);
    RUN(test_atdiskrd_e2e);
    RUN(test_atdiskwr_e2e);
    RUN(test_dial_by_alias);
    RUN(test_dial_seven_digits);
    RUN(test_dial_host_starting_with_p);
    RUN(test_dial_uppercase_modifier_keeps_host);
    RUN(test_plus_plus_plus_escape);
    RUN(test_atrd_in_call_errors);

    /* Sprint 49 — NVRAM persistence + boot */
    RUN(test_nvram_roundtrip);
    RUN(test_nvram_not_saved_without_atw);
    RUN(test_view_stored_vs_current);
    RUN(test_cli_creds_override_nvram);
    RUN(test_boot_autoexec);
    RUN(test_factory_reset_persists);
    RUN(test_boot_wifi_auto_associate);

    /* Real host-network bridge (read-only) */
    RUN(test_realnet_ati_reports_host_ip);
    RUN(test_realnet_atc_returns_real_status);
    RUN(test_realnet_off_is_simulated);

    /* Sprint 60 — firmware v0.2.0 TLS termination */
    RUN(test_tls_cv_default_off);
    RUN(test_tls_cv1_without_ca_errors);
    RUN(test_tls_ca_upload_enables_verify);
    RUN(test_tls_dial_prefix_routed);
    RUN(test_tls_atget_https_routed);
    RUN(test_help_lists_tls_commands);
    RUN(test_tls_ca_persists_across_reboot);

    unlink(PW_NVRAM_TEST);
    unlink(PW_NVRAM_CA);

    printf("\n═══════════════════════════════════════════════════════\n");
    printf("  Results: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("═══════════════════════════════════════════════════════\n\n");

    return tests_failed > 0 ? 1 : 0;
}
