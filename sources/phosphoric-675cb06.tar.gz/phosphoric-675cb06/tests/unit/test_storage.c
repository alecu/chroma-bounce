/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file test_storage.c
 * @brief Storage subsystem tests (Sedoric, FDC)
 * @author bmarty <bmarty@mailo.com>
 * @date 2026-02-23
 * @version 1.0.0-beta.7
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "storage/sedoric.h"
#include "storage/disk.h"
#include "storage/disk_http.h"
#include "io/microdisc.h"

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) static void name(void)
#define RUN(name) do { \
    printf("  %-50s", #name); \
    name(); \
    tests_passed++; \
    printf("PASS\n"); \
} while(0)

#define ASSERT_EQ(a, b) do { \
    if ((a) != (b)) { \
        printf("FAIL\n    %s:%d: expected 0x%X, got 0x%X\n", __FILE__, __LINE__, (unsigned)(b), (unsigned)(a)); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_TRUE(x) do { \
    if (!(x)) { \
        printf("FAIL\n    %s:%d: expected true\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

#define ASSERT_FALSE(x) do { \
    if ((x)) { \
        printf("FAIL\n    %s:%d: expected false\n", __FILE__, __LINE__); \
        tests_failed++; return; \
    } \
} while(0)

/* Test signal tracking */
static bool test_drq_set = false;
static bool test_intrq_set = false;

static void test_set_drq(void* ud)   { (void)ud; test_drq_set = true; }
static void test_clr_drq(void* ud)   { (void)ud; test_drq_set = false; }
static void test_set_intrq(void* ud) { (void)ud; test_intrq_set = true; }
static void test_clr_intrq(void* ud) { (void)ud; test_intrq_set = false; }

static void fdc_init_test(fdc_t* fdc) {
    fdc_init(fdc);
    fdc->set_drq = test_set_drq;
    fdc->clr_drq = test_clr_drq;
    fdc->set_intrq = test_set_intrq;
    fdc->clr_intrq = test_clr_intrq;
    test_drq_set = false;
    test_intrq_set = false;
}

/* ═══════════════════════════════════════════════════════════════════ */
/*  SEDORIC TESTS                                                     */
/* ═══════════════════════════════════════════════════════════════════ */

TEST(test_sedoric_create) {
    sedoric_disk_t* disk = sedoric_create();
    ASSERT_TRUE(disk != NULL);
    ASSERT_TRUE(disk->data != NULL);
    ASSERT_EQ(disk->tracks, 42);
    ASSERT_EQ(disk->sectors, 17);
    ASSERT_FALSE(disk->modified);
    sedoric_destroy(disk);
}

/* Blank double-sided + raw geometry inference on reload (the geometry
 * that Sedoric's INIT B formats; a single-sided blank was undersized). */
TEST(test_sedoric_create_blank_double_sided) {
    sedoric_disk_t* disk = sedoric_create_blank(42, 2);
    ASSERT_TRUE(disk != NULL);
    ASSERT_EQ(disk->tracks, 42);
    ASSERT_EQ(disk->sides, 2);
    ASSERT_EQ(disk->sectors, 17);
    ASSERT_EQ(disk->size, (uint32_t)(2 * 42 * 17 * 256));  /* 365568 */

    /* Round-trip: the double-sided geometry must be re-inferred from the size. */
    const char* path = "test_blank_ds.dsk";
    ASSERT_TRUE(sedoric_save(disk, path));
    sedoric_destroy(disk);
    sedoric_disk_t* re = sedoric_load(path);
    ASSERT_TRUE(re != NULL);
    ASSERT_EQ(re->tracks, 42);
    ASSERT_EQ(re->sides, 2);
    sedoric_destroy(re);
    remove(path);
}

TEST(test_sedoric_sector_rw) {
    sedoric_disk_t* disk = sedoric_create();
    uint8_t write_buf[256];
    uint8_t read_buf[256];
    memset(write_buf, 0xAA, 256);

    ASSERT_TRUE(sedoric_write_sector(disk, 1, 1, write_buf));
    ASSERT_TRUE(disk->modified);

    memset(read_buf, 0, 256);
    ASSERT_TRUE(sedoric_read_sector(disk, 1, 1, read_buf));
    ASSERT_EQ(read_buf[0], 0xAA);
    ASSERT_EQ(read_buf[255], 0xAA);

    sedoric_destroy(disk);
}

TEST(test_sedoric_invalid_sector) {
    sedoric_disk_t* disk = sedoric_create();

    /* Sector 0 is invalid (1-based) */
    ASSERT_TRUE(sedoric_get_sector(disk, 0, 0) == NULL);
    /* Track out of range */
    ASSERT_TRUE(sedoric_get_sector(disk, 50, 1) == NULL);
    /* Sector out of range */
    ASSERT_TRUE(sedoric_get_sector(disk, 0, 20) == NULL);

    uint8_t buf[256];
    ASSERT_FALSE(sedoric_read_sector(disk, 50, 1, buf));

    sedoric_destroy(disk);
}

TEST(test_sedoric_system_info) {
    sedoric_disk_t* disk = sedoric_create();
    uint8_t buf[256];
    ASSERT_TRUE(sedoric_read_sector(disk, 0, 1, buf));
    ASSERT_EQ(buf[0], 'S');
    ASSERT_EQ(buf[1], 'E');
    ASSERT_EQ(buf[2], 'D');
    sedoric_destroy(disk);
}

/* ═══════════════════════════════════════════════════════════════════ */
/*  FDC TESTS                                                        */
/* ═══════════════════════════════════════════════════════════════════ */

TEST(test_fdc_init) {
    fdc_t fdc;
    fdc_init(&fdc);
    ASSERT_EQ(fdc.tracks, 80);
    ASSERT_EQ(fdc.sectors_per_track, 17);
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
}

TEST(test_fdc_reset) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    fdc.track = 10;
    fdc.sector = 5;
    fdc_reset(&fdc);
    ASSERT_EQ(fdc.track, 0);
    ASSERT_EQ(fdc.sector, 1);
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
}

TEST(test_fdc_restore) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    /* Need disk data for successful restore */
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);
    fdc.c_track = 20;
    fdc.track = 20;
    fdc_write(&fdc, 0, 0x00); /* Restore */
    ASSERT_EQ(fdc.track, 0);
    ASSERT_EQ(fdc.c_track, 0);
    /* INTRQ is delayed by 20 cycles */
    ASSERT_FALSE(test_intrq_set);
    fdc_ticktock(&fdc, 25);
    ASSERT_TRUE(test_intrq_set);
    /* Status should have TRK0 bit set */
    ASSERT_TRUE(fdc.status & FDC_STI_TRK0);
    free(disk_data);
}

TEST(test_fdc_seek) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);
    fdc_write(&fdc, 3, 15); /* DATA = 15 */
    fdc_write(&fdc, 0, 0x10); /* Seek */
    ASSERT_EQ(fdc.track, 15);
    ASSERT_EQ(fdc.c_track, 15);
    fdc_ticktock(&fdc, 25);
    ASSERT_TRUE(test_intrq_set);
    free(disk_data);
}

TEST(test_fdc_bad_sector_map) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    ASSERT_EQ(fdc.bad.count, 0);          /* fdc_init clears the map */
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    disk_data[(5 - 1) * 256] = 0xCC;      /* track 0 sector 5 first byte */
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    /* Inject: side 0, track 0, sector 5 unreadable */
    ASSERT_EQ(fdc_add_bad_sector(&fdc, 0, 0, 5), 0);
    ASSERT_EQ(fdc.bad.count, 1);

    /* Reading the bad sector -> Record Not Found, INTRQ, no DRQ */
    fdc.c_track = 0;
    fdc.track = 0;
    fdc.sector = 5;
    fdc_write(&fdc, 0, 0x80); /* Read sector */
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
    ASSERT_TRUE(fdc.status & FDC_ST_NOT_FOUND);
    ASSERT_TRUE(test_intrq_set);
    ASSERT_FALSE(test_drq_set);

    /* The neighbouring sector still reads fine */
    test_intrq_set = false;
    fdc.sector = 4;
    fdc_write(&fdc, 0, 0x80);
    ASSERT_EQ(fdc.currentop, FDC_OP_READ_SECTOR);
    fdc_ticktock(&fdc, 65);
    ASSERT_TRUE(test_drq_set);

    /* Same sector id on ANOTHER track is untouched */
    fdc.currentop = FDC_OP_NONE;
    fdc.c_track = 1;
    fdc.sector = 5;
    fdc_write(&fdc, 0, 0x80);
    ASSERT_EQ(fdc.currentop, FDC_OP_READ_SECTOR);

    /* Map full -> -1 */
    fdc.bad.count = FDC_MAX_BAD_SECTORS;
    ASSERT_EQ(fdc_add_bad_sector(&fdc, 0, 0, 6), -1);

    free(disk_data);
}

TEST(test_fdc_real_timing_seek_and_rotation) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    fdc.timing_mode = FDC_TIMING_REAL;
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    /* Seek 10 tracks at 6 ms/step (r1r0=00): INTRQ only after ~60 ms */
    fdc.data = 10;
    fdc_write(&fdc, 0, 0x10);              /* Seek */
    ASSERT_TRUE(fdc.status & FDC_ST_BUSY);
    fdc_ticktock(&fdc, 59000);
    ASSERT_FALSE(test_intrq_set);          /* head still moving */
    fdc_ticktock(&fdc, 2000);
    ASSERT_TRUE(test_intrq_set);
    ASSERT_EQ(fdc.c_track, 10);

    /* Type I status shows the LIVE index pulse: one ~4 ms window per rev */
    uint8_t st = fdc_read(&fdc, 0);
    ASSERT_FALSE(st & FDC_STI_PULSE);      /* rot ~61 ms: outside the pulse */
    fdc_ticktock(&fdc, 200000 - 61000 + 500);   /* come back past the index */
    st = fdc_read(&fdc, 0);
    ASSERT_TRUE(st & FDC_STI_PULSE);
    ASSERT_FALSE(st & FDC_STI_TRK0);       /* live TRK0: we are on track 10 */

    /* Read sector: first DRQ arrives with the rotation, not instantly */
    fdc.rot_pos = 0;                       /* head right at the index */
    fdc.sector = 1;                        /* sector 1 data ≈ 1.5 ms away */
    fdc_write(&fdc, 0, 0x80);
    ASSERT_TRUE(fdc.status & FDC_ST_BUSY);
    fdc_ticktock(&fdc, 1000);
    ASSERT_FALSE(test_drq_set);            /* sector not under the head yet */
    fdc_ticktock(&fdc, 600);
    ASSERT_TRUE(test_drq_set);

    free(disk_data);
}

TEST(test_fdc_real_timing_rnf_after_5_revs) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    fdc.timing_mode = FDC_TIMING_REAL;
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    /* Ask for a sector that does not exist: the real WD1793 keeps scanning
     * ID fields and reports RNF only after 5 index pulses (~1 s) */
    fdc.sector = 200;
    fdc_write(&fdc, 0, 0x80);
    ASSERT_TRUE(fdc.status & FDC_ST_BUSY);
    ASSERT_FALSE(test_intrq_set);
    fdc_ticktock(&fdc, 999000);
    ASSERT_FALSE(test_intrq_set);          /* still scanning */
    ASSERT_TRUE(fdc.status & FDC_ST_BUSY);
    fdc_ticktock(&fdc, 2000);
    ASSERT_TRUE(test_intrq_set);
    ASSERT_TRUE(fdc.status & FDC_ST_NOT_FOUND);
    ASSERT_FALSE(fdc.status & FDC_ST_BUSY);
    ASSERT_FALSE(test_drq_set);
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);

    free(disk_data);
}

TEST(test_microdisc_bad_sector_follows_media) {
    microdisc_t md;
    microdisc_init(&md);
    uint8_t* disk_a = calloc(80 * 17 * 256, 1);
    uint8_t* disk_b = calloc(80 * 17 * 256, 1);
    microdisc_set_disk(&md, 0, disk_a, 80 * 17 * 256, 80, 17);
    microdisc_set_disk(&md, 1, disk_b, 80 * 17 * 256, 80, 17);

    /* Damage sector 5 of the media in drive A: FDC map armed (A selected) */
    ASSERT_EQ(microdisc_add_bad_sector(&md, 0, 0, 0, 5), 0);
    ASSERT_EQ(md.bad_map[0].count, 1);
    ASSERT_EQ(md.fdc.bad.count, 1);

    /* Select drive B: its media is pristine, the FDC map follows */
    microdisc_write(&md, 0x0314, (uint8_t)(1 << 5));  /* drive select = B */
    ASSERT_EQ(md.drive, 1);
    ASSERT_EQ(md.fdc.bad.count, 0);

    /* Back to drive A: the damage is still on that floppy */
    microdisc_write(&md, 0x0314, 0);
    ASSERT_EQ(md.fdc.bad.count, 1);

    /* Hot-swap a NEW disk into drive A: new media, pristine surface */
    uint8_t* disk_c = calloc(80 * 17 * 256, 1);
    microdisc_set_disk(&md, 0, disk_c, 80 * 17 * 256, 80, 17);
    ASSERT_EQ(md.bad_map[0].count, 0);
    ASSERT_EQ(md.fdc.bad.count, 0);

    /* Re-pointing the SAME image (savestate restore path) keeps the map */
    ASSERT_EQ(microdisc_add_bad_sector(&md, 0, 0, 3, 7), 0);
    microdisc_set_disk(&md, 0, disk_c, 80 * 17 * 256, 80, 17);
    ASSERT_EQ(md.bad_map[0].count, 1);
    ASSERT_EQ(md.fdc.bad.count, 1);

    free(disk_a);
    free(disk_b);
    free(disk_c);
}

TEST(test_fdc_read_sector) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    disk_data[0] = 0xAA;
    disk_data[255] = 0xBB;
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    fdc.c_track = 0;
    fdc.track = 0;
    fdc.sector = 1;
    fdc_write(&fdc, 0, 0x80); /* Read sector */
    ASSERT_EQ(fdc.currentop, FDC_OP_READ_SECTOR);

    /* DRQ is delayed by 60 cycles */
    ASSERT_FALSE(test_drq_set);
    fdc_ticktock(&fdc, 65);
    ASSERT_TRUE(test_drq_set);

    /* Read first byte */
    uint8_t first = fdc_read(&fdc, 3);
    ASSERT_EQ(first, 0xAA);
    ASSERT_FALSE(test_drq_set); /* DRQ cleared after read */

    /* Advance DRQ for remaining bytes */
    for (int i = 1; i < 255; i++) {
        fdc_ticktock(&fdc, 35); /* Let DRQ fire */
        fdc_read(&fdc, 3);
    }

    /* Read last byte */
    fdc_ticktock(&fdc, 35);
    uint8_t last = fdc_read(&fdc, 3);
    ASSERT_EQ(last, 0xBB);
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);

    /* INTRQ fires after delay */
    fdc_ticktock(&fdc, 35);
    ASSERT_TRUE(test_intrq_set);

    free(disk_data);
}

TEST(test_fdc_write_sector) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    fdc.c_track = 0;
    fdc.track = 0;
    fdc.sector = 1;
    fdc_write(&fdc, 0, 0xA0); /* Write sector */
    ASSERT_EQ(fdc.currentop, FDC_OP_WRITE_SECTOR);

    /* Wait for DRQ */
    fdc_ticktock(&fdc, 505);
    ASSERT_TRUE(test_drq_set);

    /* Write 256 bytes with DRQ delays between each */
    for (int i = 0; i < 256; i++) {
        fdc_write(&fdc, 3, (uint8_t)i);
        if (i < 255) fdc_ticktock(&fdc, 35);
    }
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
    ASSERT_EQ(disk_data[0], 0x00);
    ASSERT_EQ(disk_data[1], 0x01);
    ASSERT_EQ(disk_data[255], 0xFF);
    free(disk_data);
}

/* Formats a track via the Write Track command (0xF0): a synthetic IBM/MFM
 * stream is injected (gaps, sync, A1, IDAM, ID, DAM, data) and we check
 * that the data fields land in the right sectors of the image. */
TEST(test_fdc_write_track) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    const int SPT = 4;                 /* sectors/track for this test */
    fdc.tracks = 1;
    fdc.sectors_per_track = (uint8_t)SPT;
    uint32_t sz = (uint32_t)SPT * 256;
    uint8_t* disk_data = calloc(sz, 1);
    fdc_set_disk(&fdc, disk_data, sz);
    fdc.c_track = 0; fdc.track = 0; fdc.side = 0;

    fdc_write(&fdc, 0, 0xF0);          /* Write Track */
    ASSERT_EQ(fdc.currentop, FDC_OP_WRITE_TRACK);

    /* Build + inject the track stream, sector by sector. */
    for (int s = 1; s <= SPT; s++) {
        uint8_t pre[] = { 0x4E, 0x4E, 0x00, 0x00, 0xF5, 0xF5, 0xF5 };
        for (size_t i = 0; i < sizeof(pre); i++) fdc_write(&fdc, 3, pre[i]);
        fdc_write(&fdc, 3, 0xFE);                       /* IDAM */
        fdc_write(&fdc, 3, (uint8_t)fdc.c_track);       /* track */
        fdc_write(&fdc, 3, 0x00);                       /* side  */
        fdc_write(&fdc, 3, (uint8_t)s);                 /* sector */
        fdc_write(&fdc, 3, 0x01);                       /* size code 1 = 256 */
        fdc_write(&fdc, 3, 0xF7);                       /* CRC */
        uint8_t gap[] = { 0x4E, 0x00, 0xF5, 0xF5, 0xF5 };
        for (size_t i = 0; i < sizeof(gap); i++) fdc_write(&fdc, 3, gap[i]);
        fdc_write(&fdc, 3, 0xFB);                       /* DAM */
        for (int i = 0; i < 256; i++)
            fdc_write(&fdc, 3, (uint8_t)(s * 16 + (i & 0x0F)));  /* pattern/sector */
        fdc_write(&fdc, 3, 0xF7);                       /* CRC */
    }

    /* The complete track (SPT data fields) must terminate the command. */
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);

    /* Each logical sector must carry its pattern at the right offset. */
    for (int s = 1; s <= SPT; s++) {
        uint8_t* sec = &disk_data[(uint32_t)(s - 1) * 256];
        ASSERT_EQ(sec[0],   (uint8_t)(s * 16 + 0));
        ASSERT_EQ(sec[15],  (uint8_t)(s * 16 + 15));
        ASSERT_EQ(sec[255], (uint8_t)(s * 16 + 15));
    }
    ASSERT_TRUE(fdc.disk_modified);
    free(disk_data);
}

/* Force Interrupt D0 (i3-i0 = 0): terminates the current command WITHOUT
 * generating an interrupt (datasheet p.15). It must still drop BUSY and
 * reload the Type I status. */
TEST(test_fdc_force_interrupt) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    fdc.currentop = FDC_OP_READ_SECTOR;
    fdc_write(&fdc, 0, 0xD0); /* Force interrupt, no interrupt condition */
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
    ASSERT_FALSE(fdc.status & FDC_ST_BUSY);
    ASSERT_FALSE(test_intrq_set);   /* D0 must NOT raise INTRQ */
}

/* Type II/III with NO media loaded: the WD1793 samples READY and does not
 * execute the command — status = NOT READY (bit 7) + INTRQ, NOT Record Not
 * Found (bit 4, which means media present but sector absent). Datasheet p.7. */
TEST(test_fdc_no_disk_is_not_ready) {
    fdc_t fdc;
    fdc_init_test(&fdc);   /* no fdc_set_disk → disk_data == NULL */
    fdc_write(&fdc, 0, 0x80);          /* Read Sector (Type II) */
    ASSERT_TRUE(fdc.status & FDC_ST_NOT_READY);   /* bit 7 */
    ASSERT_FALSE(fdc.status & FDC_ST_NOT_FOUND);  /* NOT the RNF path */
    ASSERT_TRUE(test_intrq_set);
    /* Write Sector and Read Address behave the same. */
    test_intrq_set = false;
    fdc_write(&fdc, 0, 0xA0);          /* Write Sector */
    ASSERT_TRUE(fdc.status & FDC_ST_NOT_READY);
    ASSERT_FALSE(fdc.status & FDC_ST_NOT_FOUND);
}

/* Force Interrupt D8 (i3 = 1): immediate interrupt. */
TEST(test_fdc_force_interrupt_immediate) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    fdc.currentop = FDC_OP_READ_SECTOR;
    fdc_write(&fdc, 0, 0xD8); /* Force interrupt, i3 = immediate */
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);
    ASSERT_TRUE(test_intrq_set);    /* D8 raises INTRQ immediately */
}

/* Read Address writes the TRACK address (ID byte 1), not the sector number,
 * into the sector register (datasheet p.13). */
TEST(test_fdc_read_address_loads_track) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);
    fdc.c_track = 7;            /* head over physical track 7 */
    fdc.sector  = 3;            /* sector register holds something else */
    fdc_write(&fdc, 0, 0xC0);  /* Read Address (Type III) */
    /* First DATA read yields ID byte 0 (track) and loads it into sector reg */
    fdc_read(&fdc, 3);
    ASSERT_EQ(fdc.sector, 7);
    free(disk_data);
}

/* Step-in without the T (track-update) flag must move the head (c_track) but
 * leave the track register untouched; with T set it updates both. */
TEST(test_fdc_step_track_update_flag) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);
    fdc.c_track = 5;
    fdc.track   = 5;
    fdc_write(&fdc, 0, 0x40);   /* Step-in, T = 0 → no track-register update */
    ASSERT_EQ(fdc.c_track, 6);  /* head moved */
    ASSERT_EQ(fdc.track, 5);    /* register unchanged */
    fdc_ticktock(&fdc, 25);
    fdc_write(&fdc, 0, 0x50);   /* Step-in, T = 1 → update track register */
    ASSERT_EQ(fdc.c_track, 7);
    ASSERT_EQ(fdc.track, 7);
    free(disk_data);
}

TEST(test_fdc_status_read_clears_intrq) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    test_intrq_set = true;
    fdc_read(&fdc, 0);
    ASSERT_FALSE(test_intrq_set);
}

/* ═══════════════════════════════════════════════════════════════════ */
/*  MAIN                                                              */
/* ═══════════════════════════════════════════════════════════════════ */

/* A sector write through the FDC must flag the image as modified, so the
 * Microdisc can mark the drive dirty for .dsk write-back. */
TEST(test_fdc_write_sets_modified) {
    fdc_t fdc;
    fdc_init_test(&fdc);
    ASSERT_FALSE(fdc.disk_modified);
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    fdc_set_disk(&fdc, disk_data, 80 * 17 * 256);

    fdc.c_track = 0;
    fdc.track = 0;
    fdc.sector = 1;
    fdc_write(&fdc, 0, 0xA0);          /* Write sector */
    fdc_ticktock(&fdc, 505);
    fdc_write(&fdc, 3, 0x42);          /* first data byte → mutates the image */
    ASSERT_TRUE(fdc.disk_modified);    /* flagged dirty */
    free(disk_data);
}

/* sedoric_save() must persist the in-memory image to disk so in-game saves
 * survive: write a sector, save, reload, verify the bytes round-trip. */
TEST(test_sedoric_save_roundtrip) {
    sedoric_disk_t* disk = sedoric_create();
    ASSERT_TRUE(disk != NULL);

    uint8_t buf[256];
    for (int i = 0; i < 256; i++) buf[i] = (uint8_t)(0xA0 ^ i);
    ASSERT_TRUE(sedoric_write_sector(disk, 5, 3, buf));

    const char* path = "test_storage_save.dsk";
    ASSERT_TRUE(sedoric_save(disk, path));
    sedoric_destroy(disk);

    sedoric_disk_t* reloaded = sedoric_load(path);
    ASSERT_TRUE(reloaded != NULL);
    uint8_t rd[256];
    ASSERT_TRUE(sedoric_read_sector(reloaded, 5, 3, rd));
    for (int i = 0; i < 256; i++) ASSERT_EQ(rd[i], (uint8_t)(0xA0 ^ i));
    sedoric_destroy(reloaded);
    remove(path);
}

/* Build a minimal one-track MFM_DISK image holding a single sector
 * (track 0, side 0, sector 1) and write it to `path`. */
static void make_minimal_mfm(const char* path) {
    uint8_t* img = calloc(MFM_DISK_HEADER_SIZE + MFM_TRACK_SIZE, 1);
    memcpy(img, "MFM_DISK", 8);
    img[8] = 1;   /* sides = 1 (LE uint32) */
    img[12] = 1;  /* tracks = 1 */
    uint8_t* trk = img + MFM_DISK_HEADER_SIZE;
    int p = 20;
    trk[p++] = 0xA1; trk[p++] = 0xA1; trk[p++] = 0xA1; trk[p++] = 0xFE; /* ID mark */
    trk[p++] = 0;    /* track */
    trk[p++] = 0;    /* side */
    trk[p++] = 1;    /* sector */
    trk[p++] = 1;    /* size code = 256 */
    trk[p++] = 0; trk[p++] = 0; /* ID CRC (ignored by loader) */
    p += 12;         /* gap */
    trk[p++] = 0xA1; trk[p++] = 0xA1; trk[p++] = 0xA1; trk[p++] = 0xFB; /* data mark */
    for (int k = 0; k < 256; k++) trk[p++] = 0x55;
    trk[p++] = 0; trk[p++] = 0; /* data CRC placeholder */
    FILE* fp = fopen(path, "wb");
    fwrite(img, 1, MFM_DISK_HEADER_SIZE + MFM_TRACK_SIZE, fp);
    fclose(fp);
    free(img);
}

/* Regression: writing back an MFM_DISK must re-inject sectors in place into
 * the MFM container (with valid CRC), NOT dump the flat buffer over it. */
TEST(test_sedoric_mfm_writeback_roundtrip) {
    const char* path = "test_storage_mfm.dsk";
    make_minimal_mfm(path);
    long mfm_size = MFM_DISK_HEADER_SIZE + MFM_TRACK_SIZE;

    sedoric_disk_t* disk = sedoric_load(path);
    ASSERT_TRUE(disk != NULL);
    ASSERT_TRUE(disk->is_mfm);
    ASSERT_TRUE(disk->mfm_raw != NULL);

    uint8_t* sec = sedoric_get_sector(disk, 0, 1);
    ASSERT_TRUE(sec != NULL);
    ASSERT_EQ(sec[0], 0x55);            /* extracted from MFM */
    sec[0] = 0xDE; sec[1] = 0xAD;
    ASSERT_TRUE(sedoric_save(disk, path));
    sedoric_destroy(disk);

    /* File must still be a valid MFM container of the same size (not a flat dump) */
    FILE* fp = fopen(path, "rb");
    ASSERT_TRUE(fp != NULL);
    fseek(fp, 0, SEEK_END);
    ASSERT_EQ((long)ftell(fp), mfm_size);
    fclose(fp);

    sedoric_disk_t* reloaded = sedoric_load(path);
    ASSERT_TRUE(reloaded != NULL);
    ASSERT_TRUE(reloaded->is_mfm);
    uint8_t* rsec = sedoric_get_sector(reloaded, 0, 1);
    ASSERT_TRUE(rsec != NULL);
    ASSERT_EQ(rsec[0], 0xDE);
    ASSERT_EQ(rsec[1], 0xAD);
    sedoric_destroy(reloaded);
    remove(path);
}

/* ═══════════════════════════════════════════════════════════════════════
 *  Web-backed disk (loci-webdisk archi B): the FDC pulls raw MFM tracks from
 *  an HTTP disk server on demand. A forked one-shot server serves a synthetic
 *  MFM_DISK image by byte range (?offset=&len=), exactly like disk_server.py.
 * ═══════════════════════════════════════════════════════════════════════ */

/* Serve @path forever by HTTP byte-range (?offset=&len=), one request at a
 * time. Runs in the child; the parent kills it when the test ends. */
static void web_serve_file(int listen_fd, const char* path) {
    for (;;) {
        int c = accept(listen_fd, NULL, NULL);
        if (c < 0) continue;
        char req[1024]; ssize_t rn = read(c, req, sizeof(req) - 1);
        if (rn <= 0) { close(c); continue; }
        req[rn] = '\0';
        long off = 0, len = 0;
        char* o = strstr(req, "offset="); if (o) off = atol(o + 7);
        char* l = strstr(req, "len=");    if (l) len = atol(l + 4);
        FILE* fp = fopen(path, "rb");
        uint8_t* buf = calloc(1, (size_t)(len > 0 ? len : 1));
        long got = 0;
        if (fp) { fseek(fp, off, SEEK_SET); got = (long)fread(buf, 1, (size_t)len, fp); fclose(fp); }
        char hdr[160];
        int hn = snprintf(hdr, sizeof(hdr),
            "HTTP/1.1 206 Partial Content\r\nContent-Length: %ld\r\n"
            "Connection: close\r\n\r\n", got);
        (void)!write(c, hdr, (size_t)hn);
        (void)!write(c, buf, (size_t)got);
        free(buf); close(c);
    }
}

TEST(test_fdc_web_read_sector) {
    /* Synthetic MFM disk (track 0, side 0, sector 1 filled with 0x55). */
    const char* path = "test_storage_web.dsk";
    make_minimal_mfm(path);

    int lfd = socket(AF_INET, SOCK_STREAM, 0);
    ASSERT_TRUE(lfd >= 0);
    int one = 1; setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    struct sockaddr_in sa; memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET; sa.sin_addr.s_addr = htonl(INADDR_LOOPBACK); sa.sin_port = 0;
    ASSERT_TRUE(bind(lfd, (struct sockaddr*)&sa, sizeof(sa)) == 0);
    ASSERT_TRUE(listen(lfd, 4) == 0);
    socklen_t sl = sizeof(sa); getsockname(lfd, (struct sockaddr*)&sa, &sl);
    uint16_t port = ntohs(sa.sin_port);

    pid_t pid = fork();
    ASSERT_TRUE(pid >= 0);
    if (pid == 0) { web_serve_file(lfd, path); _exit(0); }
    close(lfd);

    char url[128];
    snprintf(url, sizeof(url), "http://127.0.0.1:%u/disk/%s", port, path);

    /* FDC with an EMPTY flat image + web backing: the track must be fetched. */
    fdc_t fdc;
    fdc_init_test(&fdc);
    uint8_t* flat = calloc(1 * 17 * 256, 1);        /* 1 track, zeroed */
    fdc_set_disk(&fdc, flat, 1 * 17 * 256);
    fdc.tracks = 1; fdc.sectors_per_track = 17;
    fdc_set_web(&fdc, url);
    ASSERT_TRUE(fdc.web);

    fdc.c_track = 0; fdc.track = 0; fdc.sector = 1;
    fdc_write(&fdc, 0, 0x80);                        /* Read sector 1 */
    ASSERT_EQ(fdc.currentop, FDC_OP_READ_SECTOR);
    fdc_ticktock(&fdc, 65);
    ASSERT_TRUE(test_drq_set);

    /* All 256 bytes must equal 0x55 — proving the track came from HTTP and
     * was MFM-extracted into the flat image. */
    uint8_t first = fdc_read(&fdc, 3);
    ASSERT_EQ(first, 0x55);
    for (int i = 1; i < 256; i++) {
        fdc_ticktock(&fdc, 35);
        uint8_t b = fdc_read(&fdc, 3);
        ASSERT_EQ(b, 0x55);
    }

    kill(pid, SIGKILL); waitpid(pid, NULL, 0);
    free(flat); remove(path);
}

/* ═══════════════════════════════════════════════════════════════════ */
/*  WD1793 FIDELITY (V2-E6) — deviations re-examined                   */
/* ═══════════════════════════════════════════════════════════════════ */

/* LOST DATA (S2): the platter does not wait for the CPU. If the previous DRQ has
 * not been serviced when the next byte arrives, the WD1793 raises S2 and carries on.
 * At 250 kbit/s, the program has only 32 µs per byte. */
TEST(test_fdc_lost_data_when_cpu_too_slow) {
    fdc_t fdc;
    uint8_t* disk = calloc(80 * 17 * 256, 1);
    fdc_init_test(&fdc);
    fdc_set_disk(&fdc, disk, 80 * 17 * 256);
    fdc.timing_mode = FDC_TIMING_FAST;

    fdc_write(&fdc, FDC_TRACK, 0);
    fdc_write(&fdc, FDC_SECTOR, 1);
    fdc_write(&fdc, FDC_COMMAND, 0x80);      /* Read Sector */

    /* Let time run without ever reading the data register:
     * each unserviced DRQ must cost one lost byte. */
    for (int i = 0; i < 20; i++) fdc_ticktock(&fdc, 64);

    ASSERT_TRUE((fdc_read(&fdc, FDC_STATUS) & FDC_ST_LOST_DATA) != 0);
    ASSERT_TRUE(fdc.lost_data_count > 0);
    free(disk);
}

/* …and the transfer stays clean when the CPU reads in time: no lost byte. */
TEST(test_fdc_no_lost_data_when_cpu_keeps_up) {
    fdc_t fdc;
    uint8_t* disk = calloc(80 * 17 * 256, 1);
    fdc_init_test(&fdc);
    fdc_set_disk(&fdc, disk, 80 * 17 * 256);
    fdc.timing_mode = FDC_TIMING_FAST;

    fdc_write(&fdc, FDC_TRACK, 0);
    fdc_write(&fdc, FDC_SECTOR, 1);
    fdc_write(&fdc, FDC_COMMAND, 0x80);

    for (int i = 0; i < 256; i++) {
        int guard = 0;
        while (!(fdc.status & FDC_ST_DRQ) && guard++ < 10000) fdc_ticktock(&fdc, 1);
        if (!(fdc.status & FDC_ST_DRQ)) break;
        (void)fdc_read(&fdc, FDC_DATA);      /* serviced immediately */
    }
    ASSERT_EQ(fdc.lost_data_count, 0u);
    ASSERT_TRUE((fdc.status & FDC_ST_LOST_DATA) == 0);
    free(disk);
}

/* Write-protect tab (S6): the write command is not executed, the
 * status carries bit 6, and the disk content stays intact. */
TEST(test_fdc_write_protect_refuses_write) {
    fdc_t fdc;
    uint8_t* disk = calloc(80 * 17 * 256, 1);
    fdc_init_test(&fdc);
    fdc_set_disk(&fdc, disk, 80 * 17 * 256);
    fdc_set_write_protect(&fdc, true);

    uint8_t before = disk[0];
    fdc_write(&fdc, FDC_TRACK, 0);
    fdc_write(&fdc, FDC_SECTOR, 1);
    fdc_write(&fdc, FDC_COMMAND, 0xA0);      /* Write Sector */

    ASSERT_TRUE((fdc.status & FDC_ST_WRITE_PROT) != 0);
    ASSERT_EQ(fdc.currentop, FDC_OP_NONE);   /* command not executed */
    fdc_write(&fdc, FDC_DATA, 0x5A);         /* a stray write does not get through */
    ASSERT_EQ(disk[0], before);
    free(disk);
}

/* Without the tab, the same sequence does write. */
TEST(test_fdc_write_allowed_without_protect) {
    fdc_t fdc;
    uint8_t* disk = calloc(80 * 17 * 256, 1);
    fdc_init_test(&fdc);
    fdc_set_disk(&fdc, disk, 80 * 17 * 256);
    fdc.timing_mode = FDC_TIMING_FAST;

    fdc_write(&fdc, FDC_TRACK, 0);
    fdc_write(&fdc, FDC_SECTOR, 1);
    fdc_write(&fdc, FDC_COMMAND, 0xA0);
    ASSERT_TRUE((fdc.status & FDC_ST_WRITE_PROT) == 0);
    ASSERT_TRUE(fdc.currentop == FDC_OP_WRITE_SECTOR);
    free(disk);
}

/* In Type I, status bit 6 also reports the tab. */
TEST(test_fdc_write_protect_visible_in_type1_status) {
    fdc_t fdc;
    uint8_t* disk = calloc(80 * 17 * 256, 1);
    fdc_init_test(&fdc);
    fdc_set_disk(&fdc, disk, 80 * 17 * 256);
    fdc.timing_mode = FDC_TIMING_REAL;
    fdc_set_write_protect(&fdc, true);

    fdc_write(&fdc, FDC_COMMAND, 0x00);      /* Restore (Type I) */
    for (int i = 0; i < 200; i++) fdc_ticktock(&fdc, 1000);
    ASSERT_TRUE((fdc_read(&fdc, FDC_STATUS) & FDC_ST_WRITE_PROT) != 0);
    free(disk);
}

/* ── FDC savestate (2.4.0): resume in the middle of a transfer ───────────
 * Before 2.4.0, the current-sector pointer was reset to NULL on load: the
 * next read ended in RECORD NOT FOUND. */
TEST(test_fdc_state_resume_mid_sector_read) {
    uint8_t* disk_data = calloc(80 * 17 * 256, 1);
    ASSERT_TRUE(disk_data != NULL);
    for (int i = 0; i < 80 * 17 * 256; i++) disk_data[i] = (uint8_t)(i * 7 + i / 256);
    fdc_t a, b;
    fdc_init_test(&a);
    fdc_set_disk(&a, disk_data, 80 * 17 * 256);
    a.tracks = 80; a.sectors_per_track = 17;
    a.c_track = 0; a.track = 0; a.sector = 3;
    fdc_write(&a, 0, 0x80);                    /* READ SECTOR 3 */
    fdc_ticktock(&a, 65);
    for (int i = 0; i < 100; i++) { (void)fdc_read(&a, 3); fdc_ticktock(&a, 33); }

    FILE* fp = tmpfile();
    ASSERT_TRUE(fp != NULL);
    fdc_state_save(&a, fp);
    long n = ftell(fp);
    ASSERT_EQ(n, FDC_STATE_SIZE);
    rewind(fp);
    fdc_init_test(&b);
    fdc_set_disk(&b, disk_data, 80 * 17 * 256);
    b.tracks = 80; b.sectors_per_track = 17;
    fdc_state_load(&b, fp, (uint32_t)n);
    fclose(fp);
    fdc_state_resume(&b);

    ASSERT_TRUE(b.cur_sector_data == a.cur_sector_data);
    ASSERT_EQ(b.cur_offset, 100);
    int differ = 0;
    for (int i = 100; i < 256; i++) {
        uint8_t va = fdc_read(&a, 3), vb = fdc_read(&b, 3);
        if (va != vb || vb != disk_data[2 * 256 + i]) differ++;
        fdc_ticktock(&a, 33); fdc_ticktock(&b, 33);
    }
    ASSERT_EQ(differ, 0);
    ASSERT_FALSE(b.status & FDC_ST_NOT_FOUND);
    ASSERT_EQ(b.currentop, a.currentop);
    free(disk_data);
}

/* A v1 state (36 bytes, .ost older than 2.4.0) still loads; the missing v2
 * fields take their neutral value. */
TEST(test_fdc_state_load_v1_compat) {
    fdc_t a, b;
    fdc_init_test(&a);
    a.status = 0x81; a.track = 12; a.rot_pos = 4321; a.drq_age = 17; a.wt_state = 2;
    FILE* fp = tmpfile();
    ASSERT_TRUE(fp != NULL);
    fdc_state_save(&a, fp);
    rewind(fp);
    fdc_init_test(&b);
    b.drq_age = 99; b.wt_state = 1;
    fdc_state_load(&b, fp, FDC_STATE_SIZE_V1);
    fclose(fp);
    ASSERT_EQ(b.status, 0x81);
    ASSERT_EQ(b.track, 12);
    ASSERT_EQ(b.rot_pos, 4321);
    ASSERT_EQ(b.drq_age, 0);
    ASSERT_EQ(b.wt_state, 0);
}

/* An MFM track whose ID marks announce a side or a track outside the image
 * (found by `make fuzz`, tests/fuzz/regressions/disk/): the sector is skipped
 * instead of writing 256 bytes past the array (extraction) or reading past it
 * (.dsk write-back). The valid sector is still read. */
static size_t mfm_put_sector(uint8_t* t, size_t at, uint8_t trk, uint8_t side,
                             uint8_t sec, uint8_t fill) {
    static const uint8_t am[3] = { 0xA1, 0xA1, 0xA1 };
    memcpy(t + at, am, 3); t[at + 3] = 0xFE;
    t[at + 4] = trk; t[at + 5] = side; t[at + 6] = sec; t[at + 7] = 1;
    at += 22;                                   /* ID + CRC + gap */
    memcpy(t + at, am, 3); t[at + 3] = 0xFB;
    memset(t + at + 4, fill, 256);
    return at + 4 + 256 + 2 + 30;
}

TEST(test_mfm_id_marks_outside_image_are_skipped) {
    uint8_t track[MFM_TRACK_SIZE];
    memset(track, 0x4E, sizeof track);
    size_t at = 100;
    at = mfm_put_sector(track, at, 0, 0, 1, 0x11);     /* valid */
    at = mfm_put_sector(track, at, 0, 200, 2, 0x22);   /* side 200 */
    (void)mfm_put_sector(track, at, 250, 0, 3, 0x33);  /* track 250 */

    /* Bounded extraction: a sentinel buffer follows the one-track image. */
    const uint32_t flat_size = 17 * 256;
    uint8_t* flat = (uint8_t*)malloc(flat_size + 1024);
    ASSERT_TRUE(flat != NULL);
    memset(flat, 0, flat_size);
    memset(flat + flat_size, 0xCC, 1024);
    int got = sedoric_mfm_extract_track(track, flat, flat_size, 17, 1);
    ASSERT_EQ(got, 1);
    ASSERT_EQ(flat[0], 0x11);
    for (int i = 0; i < 1024; i++) ASSERT_EQ(flat[flat_size + i], 0xCC);
    free(flat);

    /* Same track in an MFM_DISK .dsk (1 side, 1 track): load, then write
     * back without any access outside the image. */
    const char* path = "/tmp/phosphoric_test_mfm_ids.dsk";
    FILE* f = fopen(path, "wb");
    ASSERT_TRUE(f != NULL);
    uint8_t hdr[MFM_DISK_HEADER_SIZE] = { 'M','F','M','_','D','I','S','K', 1,0,0,0, 1,0,0,0 };
    fwrite(hdr, 1, sizeof hdr, f);
    fwrite(track, 1, sizeof track, f);
    fclose(f);
    sedoric_disk_t* d = sedoric_load(path);
    ASSERT_TRUE(d != NULL);
    ASSERT_EQ(d->size, flat_size);
    ASSERT_EQ(d->data[0], 0x11);
    ASSERT_EQ(d->data[256], 0x00);            /* sector 2 (side 200) skipped */
    d->data[0] = 0x44;
    d->modified = true;
    ASSERT_TRUE(sedoric_save(d, path));
    sedoric_destroy(d);
    d = sedoric_load(path);
    ASSERT_TRUE(d != NULL);
    ASSERT_EQ(d->data[0], 0x44);               /* the valid sector was written back */
    sedoric_destroy(d);
    unlink(path);
}

/* A sector whose CRC would overflow the track (data mark too close to the
 * end) is neither read nor written back: before 2.8.0, the write-back put the
 * CRC's 2nd byte on the first byte of the next track (past the file for the
 * last track). Found by `make fuzz`. */
TEST(test_mfm_sector_crossing_track_end_is_ignored) {
    const char* path = "/tmp/phosphoric_test_mfm_end.dsk";
    uint8_t hdr[MFM_DISK_HEADER_SIZE] = { 'M','F','M','_','D','I','S','K', 1,0,0,0, 2,0,0,0 };
    uint8_t t0[MFM_TRACK_SIZE], t1[MFM_TRACK_SIZE];
    memset(t0, 0x4E, sizeof t0);
    memset(t1, 0x4E, sizeof t1);
    (void)mfm_put_sector(t0, 100, 0, 0, 1, 0x11);             /* normal sector */
    size_t j = MFM_TRACK_SIZE - 261;                           /* CRC would overflow by 1 byte */
    size_t id = j - 22;
    t0[id] = t0[id + 1] = t0[id + 2] = 0xA1; t0[id + 3] = 0xFE;
    t0[id + 4] = 0; t0[id + 5] = 0; t0[id + 6] = 2; t0[id + 7] = 1;
    t0[j] = t0[j + 1] = t0[j + 2] = 0xA1; t0[j + 3] = 0xFB;
    memset(t0 + j + 4, 0x22, 256);
    t1[0] = 0x5A;                                              /* sentinel */
    FILE* f = fopen(path, "wb");
    ASSERT_TRUE(f != NULL);
    fwrite(hdr, 1, sizeof hdr, f);
    fwrite(t0, 1, sizeof t0, f);
    fwrite(t1, 1, sizeof t1, f);
    fclose(f);

    sedoric_disk_t* d = sedoric_load(path);
    ASSERT_TRUE(d != NULL);
    ASSERT_EQ(d->data[0], 0x11);
    ASSERT_EQ(d->data[256], 0x00);             /* sector 2 straddles the end: skipped */
    d->modified = true;
    ASSERT_TRUE(sedoric_save(d, path));
    sedoric_destroy(d);

    f = fopen(path, "rb");
    ASSERT_TRUE(f != NULL);
    fseek(f, MFM_DISK_HEADER_SIZE + MFM_TRACK_SIZE, SEEK_SET);
    ASSERT_EQ(fgetc(f), 0x5A);                 /* track 1 untouched */
    fclose(f);
    unlink(path);
}

int main(void) {
    printf("Running Storage tests...\n");
    printf("═══════════════════════════════════════════════════════════\n");

    printf("\n  Sedoric:\n");
    RUN(test_sedoric_create);
    RUN(test_sedoric_create_blank_double_sided);
    RUN(test_sedoric_sector_rw);
    RUN(test_sedoric_invalid_sector);
    RUN(test_sedoric_system_info);

    printf("\n  FDC WD1793:\n");
    RUN(test_fdc_init);
    RUN(test_fdc_reset);
    RUN(test_fdc_restore);
    RUN(test_fdc_seek);
    RUN(test_fdc_bad_sector_map);
    RUN(test_fdc_real_timing_seek_and_rotation);
    RUN(test_fdc_real_timing_rnf_after_5_revs);
    RUN(test_microdisc_bad_sector_follows_media);
    RUN(test_fdc_read_sector);
    RUN(test_fdc_write_sector);
    RUN(test_fdc_write_track);
    RUN(test_fdc_write_sets_modified);
    RUN(test_fdc_force_interrupt);
    RUN(test_fdc_no_disk_is_not_ready);
    RUN(test_fdc_force_interrupt_immediate);
    RUN(test_fdc_read_address_loads_track);
    RUN(test_fdc_step_track_update_flag);
    RUN(test_fdc_status_read_clears_intrq);

    printf("\n  Disk persistence:\n");
    RUN(test_sedoric_save_roundtrip);
    RUN(test_sedoric_mfm_writeback_roundtrip);
    RUN(test_fdc_web_read_sector);

    printf("\n  Fidélité WD1793 (V2-E6):\n");
    RUN(test_fdc_lost_data_when_cpu_too_slow);
    RUN(test_fdc_no_lost_data_when_cpu_keeps_up);
    RUN(test_fdc_write_protect_refuses_write);
    RUN(test_fdc_write_allowed_without_protect);
    RUN(test_fdc_write_protect_visible_in_type1_status);
    RUN(test_fdc_state_resume_mid_sector_read);
    RUN(test_fdc_state_load_v1_compat);
    RUN(test_mfm_id_marks_outside_image_are_skipped);
    RUN(test_mfm_sector_crossing_track_end_is_ignored);

    printf("\n═══════════════════════════════════════════════════════════\n");
    printf("Results: %d passed, %d failed\n", tests_passed, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
