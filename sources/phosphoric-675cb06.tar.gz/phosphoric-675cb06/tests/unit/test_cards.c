/* SPDX-License-Identifier: EUPL-1.2 */
/**
 * @file test_cards.c
 * @brief Expansion card registry (F1 menu): state read from the command
 *        line, exclusive groups, I/O conflicts, restart options,
 *        configuration
 * @author bmarty <bmarty@mailo.com>
 */
#define _DEFAULT_SOURCE              /* symlink, setenv, mkstemp */
#include "cards.h"
#include "emulator.h"
#include "io/picowifi_detect.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) static void name(void)
#define RUN(name) do { int b = tests_failed; printf("  %-52s", #name); name(); \
    if (tests_failed == b) { tests_passed++; printf("PASS\n"); } } while (0)
#define ASSERT_TRUE(x) do { if (!(x)) { \
    printf("FAIL\n    %s:%d: %s\n", __FILE__, __LINE__, #x); tests_failed++; return; } } while (0)
#define ASSERT_STR(a, b) do { if (strcmp((a), (b)) != 0) { \
    printf("FAIL\n    %s:%d: \"%s\" != \"%s\"\n", __FILE__, __LINE__, (a), (b)); \
    tests_failed++; return; } } while (0)

/* Parameters of the LOCI card (order of the entry, card_loci.c). */
enum { LP_MODE, LP_MENU, LP_SD, LP_FLASH, LP_MODEM, LP_PORT, LP_ELF, LP_FW_FLASH, LP_FW_USB,
       LP_PORT_USB };

/* Rebuilt options, joined with spaces (simple comparison). */
static void joined(char** av, char* out, size_t sz) {
    out[0] = '\0';
    for (char** p = av; *p; p++) {
        if (p != av) strncat(out, " ", sz - strlen(out) - 1);
        strncat(out, *p, sz - strlen(out) - 1);
    }
}

TEST(test_registry_is_described) {
    ASSERT_TRUE(cards_count() >= 10);
    for (int i = 0; i < cards_count(); i++) {
        const card_desc_t* d = cards_get(i);
        ASSERT_TRUE(d->id && d->name && d->role && d->role[0]);
        for (int p = 0; p < d->nparams; p++)
            ASSERT_TRUE(d->param[p].label && d->param[p].help && d->param[p].help[0]);
        ASSERT_TRUE(cards_find(d->id) == i);
    }
    ASSERT_TRUE(cards_find("microdisc") >= 0 && cards_find("loci") >= 0);
    ASSERT_TRUE(cards_find("inexistante") < 0);
}

TEST(test_state_from_cli) {
    char* argv[] = { "oric1-emu", "-r", "roms/basic11b.rom", "--disk-rom", "roms/md.rom",
                     "--serial", "tcp:bbs:23", "--acia-addr=0380", "--mea8000", NULL };
    cards_state_t st;
    cards_state_from(&st, NULL, 9, argv);
    int md = cards_find("microdisc"), ac = cards_find("acia"), me = cards_find("mea8000");
    ASSERT_TRUE(st.card[md].on);
    ASSERT_STR(st.card[md].value[0], "roms/md.rom");
    ASSERT_TRUE(st.card[ac].on);
    ASSERT_STR(st.card[ac].value[0], "tcp:bbs:23");
    ASSERT_STR(st.card[ac].value[1], "0380");
    ASSERT_TRUE(st.card[me].on);
    ASSERT_TRUE(!st.card[cards_find("jasmin")].on);
    ASSERT_TRUE(st.card[cards_find("ula_ng")].on);          /* always present */
}

TEST(test_disk_group_is_exclusive) {
    cards_state_t st;
    cards_state_defaults(&st);
    int md = cards_find("microdisc"), ja = cards_find("jasmin"), lo = cards_find("loci");
    cards_set_on(&st, md, true);
    cards_set_on(&st, lo, true);
    ASSERT_TRUE(st.card[lo].on && !st.card[md].on);
    cards_set_on(&st, ja, true);
    ASSERT_TRUE(st.card[ja].on && !st.card[lo].on);
    cards_set_on(&st, cards_find("ula_ng"), false);         /* fixed: unchanged */
    ASSERT_TRUE(st.card[cards_find("ula_ng")].on);
}

TEST(test_io_conflict_detected) {
    cards_state_t st;
    char msg[96];
    cards_state_defaults(&st);
    cards_set_on(&st, cards_find("mageco"), true);
    cards_set_on(&st, cards_find("mea8000"), true);          /* both at $03FE */
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg));
    ASSERT_TRUE(strstr(msg, "Mageco MIDI") && strstr(msg, "MEA8000") && strstr(msg, "$03FE"));
    snprintf(st.card[cards_find("mea8000")].value[0], CARD_VALUE_MAX, "03F0");
    ASSERT_TRUE(!cards_conflict(&st, msg, sizeof msg));
}

TEST(test_build_argv_replaces_cards) {
    char* argv[] = { "oric1-emu", "-r", "roms/basic11b.rom", "--disk-rom", "roms/microdis.rom",
                     "-d", "jeu.dsk", "--loci-usb", "cle", "--fast", NULL };
    cards_state_t st;
    cards_state_from(&st, NULL, 10, argv);
    /* LOCI instead of the Microdisc, LOCI menu at startup. */
    cards_set_on(&st, cards_find("loci"), true);
    int argc2;
    char** av = cards_build_argv(&st, 10, argv, &argc2);
    char buf[512];
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu -d jeu.dsk --loci-usb cle --fast -r roms/loci/locirom --loci "
                    "--no-config-cards");
    cards_argv_free(av);
    /* LOCI off: its menu ROM reverts to BASIC, --loci-usb goes away. */
    char* argv2[] = { "oric1-emu", "-r", "roms/loci/locirom", "--loci", "--loci-usb", "cle", NULL };
    cards_state_from(&st, NULL, 6, argv2);
    cards_set_on(&st, cards_find("loci"), false);
    av = cards_build_argv(&st, 6, argv2, &argc2);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu -r roms/basic11b.rom --no-config-cards");
    ASSERT_TRUE(argc2 == 4);
    cards_argv_free(av);
}

TEST(test_build_argv_params) {
    char* argv[] = { "oric1-emu", NULL };
    cards_state_t st;
    cards_state_defaults(&st);
    int ac = cards_find("acia");
    cards_set_on(&st, ac, true);
    snprintf(st.card[ac].value[0], CARD_VALUE_MAX, "picowifi");
    snprintf(st.card[ac].value[1], CARD_VALUE_MAX, "0380");
    snprintf(st.card[ac].value[4], CARD_VALUE_MAX, "oui");      /* V23 */
    char** av = cards_build_argv(&st, 1, argv, NULL);
    char buf[256];
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --serial picowifi --acia-addr 0380 --serial-v23 --no-config-cards");
    cards_argv_free(av);
}

TEST(test_cfg_roundtrip) {
    cards_state_t st, back;
    cards_state_defaults(&st);
    int sp = cards_find("sp0256");
    cards_set_on(&st, sp, true);
    snprintf(st.card[sp].value[1], CARD_VALUE_MAX, "03F2");
    FILE* f = tmpfile();
    ASSERT_TRUE(f != NULL);
    cards_cfg_write(&st, f);
    rewind(f);
    cards_state_defaults(&back);
    char line[256];
    bool seen = false;
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\n")] = '\0';
        char* eq = strchr(line, '=');
        ASSERT_TRUE(eq != NULL);
        *eq = '\0';
        ASSERT_TRUE(cards_cfg_line(&back, line, eq + 1, &seen));
    }
    fclose(f);
    ASSERT_TRUE(seen && back.card[sp].on);
    ASSERT_STR(back.card[sp].value[1], "03F2");
    ASSERT_TRUE(!cards_cfg_line(&back, "clavier", "azerty", NULL));   /* not a card */
}

/* Fake /sys: ttyACM0 = other TinyUSB build, ttyACM1 = picowifi. */
static char g_sys[256];

static void fake_tty(const char* tty, const char* product) {
    char p[512], dev[512];
    snprintf(dev, sizeof dev, "%s/devices/usb1/%s", g_sys, tty);
    snprintf(p, sizeof p, "%s/1-1:1.0", dev);
    mkdir(dev, 0755); mkdir(p, 0755);
    snprintf(p, sizeof p, "%s/product", dev);
    FILE* f = fopen(p, "w");
    if (f) { fprintf(f, "%s\n", product); fclose(f); }
    snprintf(p, sizeof p, "%s/class/tty/%s", g_sys, tty);
    mkdir(p, 0755);
    snprintf(p, sizeof p, "%s/class/tty/%s/device", g_sys, tty);
    snprintf(dev, sizeof dev, "../../../devices/usb1/%s/1-1:1.0", tty);
    if (symlink(dev, p) != 0) perror("symlink");
}

static void fake_sysfs(bool with_picowifi) {
    char cmd[300];
    snprintf(g_sys, sizeof g_sys, "/tmp/phos_sysfs_%d", (int)getpid());
    snprintf(cmd, sizeof cmd, "rm -rf %s && mkdir -p %s/class/tty %s/devices/usb1",
             g_sys, g_sys, g_sys);
    if (system(cmd) != 0) return;
    fake_tty("ttyACM0", "TinyUSB Device");
    if (with_picowifi) fake_tty("ttyACM1", PICOWIFI_USB_PRODUCT);
    setenv("PHOSPHORIC_SYSFS_ROOT", g_sys, 1);
}

static void fake_sysfs_drop(void) {
    char cmd[300];
    snprintf(cmd, sizeof cmd, "rm -rf %s", g_sys);
    if (system(cmd) != 0) { /* nothing */ }
    unsetenv("PHOSPHORIC_SYSFS_ROOT");
}

TEST(test_picowifi_detect_by_usb_product) {
    char dev[64];
    fake_sysfs(true);
    ASSERT_TRUE(picowifi_detect(NULL, dev, sizeof dev));
    ASSERT_STR(dev, "/dev/ttyACM1");                 /* not ttyACM0 (other product) */
    fake_sysfs(false);
    ASSERT_TRUE(!picowifi_detect(NULL, dev, sizeof dev));
    ASSERT_TRUE(!picowifi_detect("/inexistant", dev, sizeof dev));
    picowifi_serial_spec("/dev/ttyACM1", dev, sizeof dev);
    ASSERT_STR(dev, "com:115200,8,N,1,/dev/ttyACM1");
    fake_sysfs_drop();
}

TEST(test_choice_param_cycles) {
    const card_desc_t* d = cards_get(cards_find("loci"));
    const card_param_t* p = NULL;
    for (int i = 0; i < d->nparams; i++) if (strcmp(d->param[i].key, "modem") == 0) p = &d->param[i];
    ASSERT_TRUE(p && p->kind == CARD_P_CHOICE && p->cli == NULL);
    char v[CARD_VALUE_MAX];
    cards_param_default(p, v, sizeof v);
    ASSERT_STR(v, LOCI_MODEM_NONE);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODEM_SIM);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODEM_REAL);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODEM_NONE);
    snprintf(v, sizeof v, "bizarre");
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODEM_NONE);
}

TEST(test_loci_modem_build_argv) {
    char* argv[] = { "oric1-emu", "--serial-trace", "t.log", NULL };
    cards_state_t st;
    int lo = cards_find("loci"), ac = cards_find("acia");
    char buf[512];
    fake_sysfs(true);
    cards_state_defaults(&st);
    cards_set_on(&st, lo, true);
    snprintf(st.card[lo].value[LP_MENU], CARD_VALUE_MAX, "non");
    snprintf(st.card[lo].value[LP_MODEM], CARD_VALUE_MAX, LOCI_MODEM_SIM);
    char** av = cards_build_argv(&st, 3, argv, NULL);
    joined(av, buf, sizeof buf);       /* --serial-trace kept: the modem is an ACIA */
    ASSERT_STR(buf, "oric1-emu --serial-trace t.log --loci --serial picowifi --no-config-cards");
    cards_argv_free(av);
    snprintf(st.card[lo].value[LP_MODEM], CARD_VALUE_MAX, LOCI_MODEM_REAL);   /* detected port */
    av = cards_build_argv(&st, 1, argv, NULL);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --loci --serial com:115200,8,N,1,/dev/ttyACM1 --no-config-cards");
    cards_argv_free(av);
    snprintf(st.card[lo].value[LP_PORT], CARD_VALUE_MAX, "/dev/ttyUSB3");     /* forced port */
    av = cards_build_argv(&st, 1, argv, NULL);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --loci --serial com:115200,8,N,1,/dev/ttyUSB3 --no-config-cards");
    cards_argv_free(av);
    /* Active ACIA card: it keeps the serial line, and the menu reports it. */
    char msg[96];
    ASSERT_TRUE(!cards_conflict(&st, msg, sizeof msg));
    cards_set_on(&st, ac, true);
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg) && strstr(msg, "une seule ligne"));
    fake_sysfs_drop();
}

TEST(test_loci_modem_real_missing_is_reported) {
    cards_state_t st;
    int lo = cards_find("loci");
    char msg[96];
    fake_sysfs(false);
    cards_state_defaults(&st);
    cards_set_on(&st, lo, true);
    snprintf(st.card[lo].value[LP_MODEM], CARD_VALUE_MAX, LOCI_MODEM_REAL);
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg) && strstr(msg, "aucun picowifi"));
    char* argv[] = { "oric1-emu", NULL };
    char** av = cards_build_argv(&st, 1, argv, NULL);
    char buf[256];
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu -r roms/loci/locirom --loci --no-config-cards");
    cards_argv_free(av);
    snprintf(st.card[lo].value[LP_PORT], CARD_VALUE_MAX, "/dev/ttyACM7");
    ASSERT_TRUE(!cards_conflict(&st, msg, sizeof msg));
    fake_sysfs_drop();
}

TEST(test_loci_modem_state_from_cli) {
    cards_state_t st;
    int lo = cards_find("loci"), ac = cards_find("acia");
    fake_sysfs(true);
    char* a1[] = { "oric1-emu", "--loci", "--serial", "picowifi", NULL };
    cards_state_from(&st, NULL, 4, a1);
    ASSERT_TRUE(st.card[lo].on && !st.card[ac].on);
    ASSERT_STR(st.card[lo].value[LP_MODEM], LOCI_MODEM_SIM);
    char* a2[] = { "oric1-emu", "--loci", "--serial", "com:115200,8,N,1,/dev/ttyACM1", NULL };
    cards_state_from(&st, NULL, 4, a2);                 /* detected port: left empty */
    ASSERT_STR(st.card[lo].value[LP_MODEM], LOCI_MODEM_REAL);
    ASSERT_STR(st.card[lo].value[LP_PORT], "");
    char* a3[] = { "oric1-emu", "--loci", "--serial", "com:115200,8,N,1,/dev/ttyS0", NULL };
    cards_state_from(&st, NULL, 4, a3);
    ASSERT_STR(st.card[lo].value[LP_PORT], "/dev/ttyS0");
    /* ACIA set otherwise (V23, credentials, other address): stays a card. */
    char* a4[] = { "oric1-emu", "--loci", "--serial", "picowifi", "--serial-v23", NULL };
    cards_state_from(&st, NULL, 5, a4);
    ASSERT_TRUE(st.card[ac].on);
    ASSERT_STR(st.card[lo].value[LP_MODEM], LOCI_MODEM_NONE);
    char* a5[] = { "oric1-emu", "--loci", "--serial", "picowifi:box:secret", NULL };
    cards_state_from(&st, NULL, 4, a5);
    ASSERT_TRUE(st.card[ac].on);
    char* a6[] = { "oric1-emu", "--serial", "picowifi", NULL };   /* without LOCI */
    cards_state_from(&st, NULL, 3, a6);
    ASSERT_TRUE(st.card[ac].on && !st.card[lo].on);
    fake_sysfs_drop();
}

TEST(test_loci_modem_cfg) {
    cards_state_t st, back;
    bool seen[16];
    int lo = cards_find("loci");
    cards_state_defaults(&st);
    cards_set_on(&st, lo, true);
    snprintf(st.card[lo].value[LP_MODEM], CARD_VALUE_MAX, LOCI_MODEM_SIM);
    char path[] = "/tmp/phos_cards_cfg_XXXXXX";
    int fd = mkstemp(path);
    ASSERT_TRUE(fd >= 0);
    FILE* f = fdopen(fd, "w");
    cards_cfg_write(&st, f);
    fclose(f);
    ASSERT_TRUE(cards_cfg_read(path, &back, seen));
    ASSERT_TRUE(back.card[lo].on);
    ASSERT_STR(back.card[lo].value[LP_MODEM], LOCI_MODEM_SIM);
    /* Configuration: LOCI + simulated modem added at launch... */
    char* a1[] = { "oric1-emu", NULL };
    int n = 0;
    char** av = cards_config_argv(path, 1, a1, &n);
    char buf[256];
    ASSERT_TRUE(av != NULL);
    joined(av, buf, sizeof buf);
    ASSERT_TRUE(strstr(buf, "--loci") && strstr(buf, "--serial picowifi"));
    cards_argv_free(av);
    /* ...unless the command line already chooses the serial line. */
    char* a2[] = { "oric1-emu", "--serial", "tcp:bbs:23", NULL };
    av = cards_config_argv(path, 3, a2, &n);
    ASSERT_TRUE(av != NULL);
    joined(av, buf, sizeof buf);
    ASSERT_TRUE(strstr(buf, "--loci") && !strstr(buf, "picowifi"));
    cards_argv_free(av);
    unlink(path);
}

/* LOCI-USB (Feather, --loci-hw): ttyACM2, next to the picowifi. */
#define LOCI_USB_FW_PRODUCT "LOCI-USB (bus 6502 pour Phosphoric)"

TEST(test_loci_usb_detect_by_usb_product) {
    char dev[64];
    fake_sysfs(true);
    ASSERT_TRUE(!loci_usb_detect(NULL, dev, sizeof dev));     /* picowifi only */
    fake_tty("ttyACM2", LOCI_USB_FW_PRODUCT);
    ASSERT_TRUE(loci_usb_detect(NULL, dev, sizeof dev));
    ASSERT_STR(dev, "/dev/ttyACM2");
    ASSERT_TRUE(picowifi_detect(NULL, dev, sizeof dev));      /* each finds its own */
    ASSERT_STR(dev, "/dev/ttyACM1");
    fake_sysfs(false);
    fake_tty("ttyACM3", "LOCI-USB loci-fw (bus 6502)");        /* loci-fw-usb firmware */
    ASSERT_TRUE(loci_usb_detect(NULL, dev, sizeof dev));
    ASSERT_STR(dev, "/dev/ttyACM3");
    fake_sysfs_drop();
}

TEST(test_loci_params_order) {
    const card_desc_t* d = cards_get(cards_find("loci"));
    static const char* const keys[] = { "mode", "menu", "sd", "flash", "modem", "port",
                                        "elf", "fw_flash", "fw_usb", "port_usb" };
    ASSERT_TRUE(d->nparams == 10);
    for (int p = 0; p < 10; p++) ASSERT_STR(d->param[p].key, keys[p]);
    ASSERT_TRUE(cards_find("loci_emu") < 0 && cards_find("loci_hw") < 0);   /* a single card */
}

TEST(test_loci_mode_params_shown) {
    const card_desc_t* d = cards_get(cards_find("loci"));
    card_choice_t c;
    memset(&c, 0, sizeof c);
    snprintf(c.value[LP_MODE], CARD_VALUE_MAX, LOCI_MODE_HLE);
    ASSERT_TRUE(cards_param_applies(d, &c, LP_MODE) && cards_param_applies(d, &c, LP_SD));
    ASSERT_TRUE(!cards_param_applies(d, &c, LP_ELF) && !cards_param_applies(d, &c, LP_PORT_USB));
    snprintf(c.value[LP_MODE], CARD_VALUE_MAX, LOCI_MODE_FW);
    ASSERT_TRUE(cards_param_applies(d, &c, LP_ELF) && cards_param_applies(d, &c, LP_FW_USB));
    ASSERT_TRUE(!cards_param_applies(d, &c, LP_MODEM) && !cards_param_applies(d, &c, LP_PORT_USB));
    snprintf(c.value[LP_MODE], CARD_VALUE_MAX, LOCI_MODE_HW);
    ASSERT_TRUE(cards_param_applies(d, &c, LP_PORT_USB) && cards_param_applies(d, &c, LP_MODE));
    ASSERT_TRUE(!cards_param_applies(d, &c, LP_MENU) && !cards_param_applies(d, &c, LP_ELF));
    const card_desc_t* md = cards_get(cards_find("microdisc"));   /* other cards: everything */
    ASSERT_TRUE(cards_param_applies(md, &c, 0));
}

TEST(test_loci_mode_cycles_available_only) {
    const card_param_t* p = &cards_get(cards_find("loci"))->param[LP_MODE];
    char v[CARD_VALUE_MAX];
    cards_param_default(p, v, sizeof v);
    ASSERT_STR(v, LOCI_MODE_HLE);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODE_FW);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODE_HW);
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODE_HLE);
    setenv("PHOSPHORIC_TEST_LOCI_BACKENDS", "hw", 1);           /* binary without libemul */
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODE_HW);
    setenv("PHOSPHORIC_TEST_LOCI_BACKENDS", "aucun", 1);        /* neither one */
    cards_choice_next(p, v, sizeof v); ASSERT_STR(v, LOCI_MODE_HLE);
    cards_state_t st;
    char msg[96];
    cards_state_defaults(&st);
    cards_set_on(&st, cards_find("loci"), true);
    snprintf(st.card[cards_find("loci")].value[LP_MODE], CARD_VALUE_MAX, LOCI_MODE_FW);
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg) && strstr(msg, "absent de ce binaire"));
    setenv("PHOSPHORIC_TEST_LOCI_BACKENDS", "emul,hw", 1);
}

TEST(test_loci_firmware_mode) {
    cards_state_t st;
    int lo = cards_find("loci");
    char buf[256], msg[96];
    char* a1[] = { "oric1-emu", "--loci-emu", "fw.elf", "--loci-usb-image", "cle.img",
                   "--loci-cdc", "/dev/ttyACM3", NULL };
    cards_state_from(&st, NULL, 7, a1);
    ASSERT_TRUE(st.card[lo].on);
    ASSERT_STR(st.card[lo].value[LP_MODE], LOCI_MODE_FW);
    ASSERT_STR(st.card[lo].value[LP_ELF], "fw.elf");
    ASSERT_STR(st.card[lo].value[LP_FW_USB], "cle.img");
    ASSERT_TRUE(!cards_conflict(&st, msg, sizeof msg));
    char** av = cards_build_argv(&st, 7, a1, NULL);   /* --loci-cdc: secondary option kept */
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --loci-cdc /dev/ttyACM3 --loci-emu fw.elf --loci-usb-image cle.img "
                    "--no-config-cards");
    cards_argv_free(av);
    st.card[lo].value[LP_ELF][0] = '\0';
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg) && strstr(msg, "ELF"));
}

TEST(test_loci_usb_mode) {
    cards_state_t st;
    int lo = cards_find("loci"), md = cards_find("microdisc");
    char buf[256], msg[96];
    fake_sysfs(true);
    fake_tty("ttyACM2", LOCI_USB_FW_PRODUCT);
    /* Command line: detected port left empty, other port kept. */
    char* a1[] = { "oric1-emu", "--loci-hw", "/dev/ttyACM2", NULL };
    cards_state_from(&st, NULL, 3, a1);
    ASSERT_TRUE(st.card[lo].on);
    ASSERT_STR(st.card[lo].value[LP_MODE], LOCI_MODE_HW);
    ASSERT_STR(st.card[lo].value[LP_PORT_USB], "");
    char* a2[] = { "oric1-emu", "--loci-hw=/dev/ttyUSB9", NULL };
    cards_state_from(&st, NULL, 2, a2);
    ASSERT_STR(st.card[lo].value[LP_PORT_USB], "/dev/ttyUSB9");
    /* « disque » group: always mutually exclusive with the Microdisc. */
    cards_set_on(&st, md, true);
    ASSERT_TRUE(!st.card[lo].on);
    cards_set_on(&st, lo, true);
    ASSERT_TRUE(!st.card[md].on);
    /* Relaunch: no --loci, no menu ROM, no settings of the built-in model. */
    char* a0[] = { "oric1-emu", "-r", "roms/loci/locirom", "--loci-flash", "f", NULL };
    snprintf(st.card[lo].value[LP_FLASH], CARD_VALUE_MAX, "f");
    st.card[lo].value[LP_PORT_USB][0] = '\0';
    ASSERT_TRUE(!cards_conflict(&st, msg, sizeof msg));
    char** av = cards_build_argv(&st, 5, a0, NULL);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu -r roms/basic11b.rom --loci-hw /dev/ttyACM2 --no-config-cards");
    cards_argv_free(av);
    snprintf(st.card[lo].value[LP_PORT_USB], CARD_VALUE_MAX, "/dev/ttyUSB9");
    av = cards_build_argv(&st, 1, a0, NULL);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --loci-hw /dev/ttyUSB9 --no-config-cards");
    cards_argv_free(av);
    /* No LOCI-USB plugged in, empty port: reported, and LOCI is not relaunched. */
    fake_sysfs(false);
    st.card[lo].value[LP_PORT_USB][0] = '\0';
    ASSERT_TRUE(cards_conflict(&st, msg, sizeof msg) && strstr(msg, "LOCI-USB"));
    av = cards_build_argv(&st, 1, a0, NULL);
    joined(av, buf, sizeof buf);
    ASSERT_STR(buf, "oric1-emu --no-config-cards");
    cards_argv_free(av);
    fake_sysfs_drop();
}

TEST(test_loci_mode_cfg) {
    cards_state_t st, back;
    bool seen[16];
    int lo = cards_find("loci");
    char path[] = "/tmp/phos_cards_mode_XXXXXX";
    int fd = mkstemp(path);
    ASSERT_TRUE(fd >= 0);
    FILE* f = fdopen(fd, "w");
    cards_state_defaults(&st);
    cards_set_on(&st, lo, true);
    snprintf(st.card[lo].value[LP_MODE], CARD_VALUE_MAX, LOCI_MODE_HW);
    snprintf(st.card[lo].value[LP_PORT_USB], CARD_VALUE_MAX, "/dev/ttyACM5");
    snprintf(st.card[lo].value[LP_SD], CARD_VALUE_MAX, "carte.img");   /* other mode: not written */
    cards_cfg_write(&st, f);
    fclose(f);
    ASSERT_TRUE(cards_cfg_read(path, &back, seen));
    ASSERT_TRUE(back.card[lo].on && seen[lo]);
    ASSERT_STR(back.card[lo].value[LP_MODE], LOCI_MODE_HW);
    ASSERT_STR(back.card[lo].value[LP_PORT_USB], "/dev/ttyACM5");
    ASSERT_STR(back.card[lo].value[LP_SD], "");
    /* Former « LOCI firmware » and « LOCI réelle » entries: modes of LOCI. */
    f = fopen(path, "w");
    fprintf(f, "carte.loci=non\ncarte.loci_emu=oui\nloci_emu.elf=fw.elf\nloci_emu.flash=-\n"
               "carte.loci_hw=non\n");
    fclose(f);
    ASSERT_TRUE(cards_cfg_read(path, &back, seen));
    ASSERT_TRUE(back.card[lo].on && seen[lo]);
    ASSERT_STR(back.card[lo].value[LP_MODE], LOCI_MODE_FW);
    ASSERT_STR(back.card[lo].value[LP_ELF], "fw.elf");
    ASSERT_STR(back.card[lo].value[LP_FW_FLASH], "-");
    ASSERT_TRUE(cards_cfg_key("loci_hw.port", 12) && cards_cfg_key("carte.loci_emu", 14));
    f = fopen(path, "w");
    fprintf(f, "carte.loci_hw=oui\nloci_hw.port=/dev/ttyACM9\n");
    fclose(f);
    ASSERT_TRUE(cards_cfg_read(path, &back, seen));
    ASSERT_STR(back.card[lo].value[LP_MODE], LOCI_MODE_HW);
    ASSERT_STR(back.card[lo].value[LP_PORT_USB], "/dev/ttyACM9");
    f = fopen(path, "w");                       /* 2.26.0: mode « réelle », key « pont » */
    fprintf(f, "carte.loci=oui\nloci.mode=réelle\nloci.pont=/dev/ttyACM4\n");
    fclose(f);
    ASSERT_TRUE(cards_cfg_read(path, &back, seen));
    ASSERT_STR(back.card[lo].value[LP_MODE], LOCI_MODE_HW);
    ASSERT_STR(back.card[lo].value[LP_PORT_USB], "/dev/ttyACM4");
    unlink(path);
}

int main(void) {
    /* LOCI firmware and usb modes: offered depending on the backends present;
     * the test pretends the binary has both. */
    setenv("PHOSPHORIC_TEST_LOCI_BACKENDS", "emul,hw", 1);
    printf("=== Registre des cartes d'extension ===\n");
    RUN(test_registry_is_described);
    RUN(test_state_from_cli);
    RUN(test_disk_group_is_exclusive);
    RUN(test_io_conflict_detected);
    RUN(test_build_argv_replaces_cards);
    RUN(test_build_argv_params);
    RUN(test_cfg_roundtrip);
    RUN(test_picowifi_detect_by_usb_product);
    RUN(test_choice_param_cycles);
    RUN(test_loci_modem_build_argv);
    RUN(test_loci_modem_real_missing_is_reported);
    RUN(test_loci_modem_state_from_cli);
    RUN(test_loci_modem_cfg);
    RUN(test_loci_usb_detect_by_usb_product);
    RUN(test_loci_params_order);
    RUN(test_loci_mode_params_shown);
    RUN(test_loci_mode_cycles_available_only);
    RUN(test_loci_firmware_mode);
    RUN(test_loci_usb_mode);
    RUN(test_loci_mode_cfg);
    printf("\nResults: %d passed, %d failed\n", tests_passed, tests_failed);
    return tests_failed ? 1 : 0;
}
