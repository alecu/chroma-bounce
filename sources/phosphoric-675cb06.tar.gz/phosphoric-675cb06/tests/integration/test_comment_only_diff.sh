#!/bin/sh
# test_comment_only_diff.sh — self-test of tools/check_comment_only_diff.py.
#
# The tool keeps the English mirror branch `main-en` identical to `main` apart
# from comments. It is checked in a throwaway git repository: a translated
# comment (even over a different number of lines) must pass; a modified string,
# identifier or command must fail, for each family of files.
set -u
TOOL="$(cd "$(dirname "$0")/../.." && pwd)/tools/check_comment_only_diff.py"
T=$(mktemp -d) || exit 1
trap 'rm -rf "$T"' EXIT
pass=0
fail=0

cd "$T" || exit 1
git init -q -b main . && git config user.email t@t && git config user.name t
cat > a.c <<'EOF'
/* Initialise le compteur
 * de trames. */
int n = 0; // valeur de départ
const char *m = "Disque inséré";
EOF
cat > b.sh <<'EOF'
#!/bin/sh
# Lance le test
echo "# pas un commentaire"  # vrai commentaire
EOF
cat > c.py <<'EOF'
# Calcule la somme
x = "texte"  # commentaire
EOF
printf 'all:\n\t@echo ok # fin\n# règle par défaut\n' > Makefile
git add -A && git commit -q -m base

expect() {  # expect <expected rc> <label>
    if python3 "$TOOL" a.c b.sh c.py Makefile >/dev/null 2>&1; then rc=0; else rc=1; fi
    if [ "$rc" = "$1" ]; then echo "PASS: $2"; pass=$((pass+1));
    else echo "FAIL: $2 (rc=$rc, attendu $1)"; fail=$((fail+1)); fi
    git checkout -q -- .
}

# Portable literal replacement: BSD/macOS `sed -i` does not take the GNU
# syntax (it would read the script as a suffix and change nothing).
edit() {  # edit <file> <old> <new>
    python3 - "$@" <<'PY' || echo "edit impossible : $2" >&2
import sys
p, a, b = sys.argv[1:4]
s = open(p, encoding="utf-8").read()
assert a in s
open(p, "w", encoding="utf-8").write(s.replace(a, b, 1))
PY
}
NL='
'

expect 0 "arbre identique accepté"

edit a.c '/* Initialise le compteur' "/* Initialises the frame${NL} * counter (one more line)"
edit a.c '// valeur de départ' '// start value'
edit b.sh '# Lance le test' '# Runs the test'
edit b.sh '# vrai commentaire' '# real comment'
edit c.py '# Calcule la somme' '# Computes the sum'
edit c.py '  # commentaire' '  # comment'
edit Makefile '# fin' '# end'
edit Makefile '# règle par défaut' '# default rule'
if git diff --quiet; then
    echo "FAIL: les modifications de commentaires n'ont pas été appliquées"; fail=$((fail+1))
fi
expect 0 "commentaires traduits (C, sh, py, Makefile) acceptés"

edit a.c 'Disque inséré' 'Disk inserted'
expect 1 "chaîne C modifiée refusée"

edit a.c 'int n = 0' 'int n = 1'
expect 1 "code C modifié refusé"

edit b.sh '# pas un commentaire' '# not a comment'
expect 1 "« # » dans une chaîne shell modifiée refusé"

edit c.py '"texte"' '"text"'
expect 1 "chaîne Python modifiée refusée"

edit Makefile '@echo ok' '@echo OK'
expect 1 "commande Makefile modifiée refusée"

echo "Tests: $((pass+fail)), Passed: $pass, Failed: $fail"
[ "$fail" -eq 0 ]
